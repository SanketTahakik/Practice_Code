/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 29/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : C++ language DSA
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef struct node
{
    int data;
    struct node * next;
}NODE, *PNODE, **PPNODE;

class SinglyLL
{
    public:
        PNODE Frist;    // characteristics

        int iCount;     // characteristics

        SinglyLL();

        void InsertFrist(int iNo);
        void InsertLast(int iNo);
        void InsertAtPos(int iNo, int iPos);

        void DeleteFrist(int iNo);
        void DeleteLast(int iNo);
        void DeleteAtPos(int iNo);

        void Display();
        int Count();
};

int main()
{
    SinglyLL obj1();

    return 0;
}