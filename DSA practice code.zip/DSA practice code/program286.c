/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 20/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Dubbly LinkedList 
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
    int data;
    struct Node *next;

}NODE, *PNODE, **PPNODE;

///////////////////////////////////////////////////////////

void InsertFrist(PPNODE Head, PPNODE Tail, int iNo)
{
    
}

void InsertLast(PPNODE Head, PPNODE Tail, int iNo)
{

}

void InsertAtPos(PPNODE Head, PPNODE Tail, int iNo)
{

}

void DeleteFrist(PPNODE Head, PPNODE Tail)
{

}

void DeleteLast(PPNODE Head, PPNODE Tail)
{

}

void DeleteAtPos(PPNODE Head, PPNODE Tail)
{

}

void Display(PNODE Head, PNODE Tail)
{

}

int Count(PNODE Head, PNODE Tail)
{

}

int main()
{
    PNODE Frist = NULL;
    PNODE Last = NULL;

    return 0;
}