/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 29/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : C++ language DSA DoublyCL new Approch
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef class node
{
    public:
        int data;
        struct node * next;
        struct node * prev;

        node()
        {
            data = 0;
            next = NULL;
            prev = NULL;
        }

        node(int value)
        {
            data = value;
            next = NULL;
            prev = NULL;
        }
}NODE, *PNODE;

class DoublyCL
{
    private:
        PNODE Frist;
        PNODE Last;
        int iCount ;
    
    public:
        DoublyCL();
        ~DoublyCL();

        void InsertFrist(int iNo);
        void InsertLast(int iNo);
        void InsertAtPos(int iNo, int iPos);

        void DeleteFrist();
        void DeleteLast();
        void DeleteAtPos(int iPos);

        void Display();
        int Count();
};

DoublyCL :: DoublyCL()
{
    
}

        void DoublyCL :: InsertFrist(int iNo)
        {

        }
        void DoublyCL ::InsertLast(int iNo)
        {

        }
        void DoublyCL :: InsertAtPos(int iNo, int iPos)
        {

        }

        void DoublyCL :: DeleteFrist()
        {

        }
        void DoublyCL :: DeleteLast()
        {

        }
        void DoublyCL :: DeleteAtPos(int iPos)
        {

        }

        void DoublyCL :: Display()
        {

        }
        int DoublyCL :: Count()
        {

        }

int main()
{


    return 0;
}