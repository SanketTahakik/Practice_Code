/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 12/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : typedef new syncat
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h> // malloc and free

typedef struct Node
{
    int no;
    struct Node *next;
}NODE, *PNODE, **PNODE;


int main()
{
    PNODE Frist = NULL;
    
    
    return 0;
}