/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 13/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Find Minimum number in LinkedList
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;

struct Node
{
    int data;
    struct Node * next;
};


// 1: Allocate memory for Node
// 2: Initalise the Node
// 3: Check whether LL is empty of Not
// 4: If LL is empty store address of newNode in Frist
// 5: Otherwise store the address of newNode nside next pointer of old node
// 6: Update frist pointer with the address of new node

void InsertFrist(PPNODE Head, int iNo)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // 1

    newn -> data = iNo; // 2
    newn -> next = NULL;    

    if(*Head == NULL)   // 3
    {
        *Head = newn;
    }
    else    // 4
    {
        newn -> next = *Head;   // 5
        *Head = newn;   //6
    }
}

int Maximum(PNODE Head)
{
    int iMax = Head -> data;
    
    if(Head == NULL)
    {
        return -1;
    }
    while(Head != NULL)
    {
        if(Head -> data > iMax)
        {
            iMax = Head -> data;
        }
        Head = Head -> next;
    }
    return iMax;
}

void Display(PNODE Head)
{
    printf("Element of LinkedList are : \n");

    while (Head != NULL)
    {
        printf("|%d| ->", Head->data);
        Head = Head -> next;
    }
    printf("NULL \n");
    
}

int main()
{
    PNODE Frist = NULL;
    int iRet = 0;

    InsertFrist(&Frist, 111);
    InsertFrist(&Frist, 101);
    InsertFrist(&Frist, 51);
    InsertFrist(&Frist, 21);
    InsertFrist(&Frist, 11);

    Display(Frist);

    iRet = Maximum(Frist);

    printf("%d", iRet);

    return 0;
}