/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 12/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Defind 8 function Display, Count, InsertFrist, InstertLast, InsertAtPos, DeleteFrist, DeleteLast, DeleteAtPos, 
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h> // malloc and free

typedef struct node NODE;
typedef struct node* PNODE;
typedef struct node** PPNODE;

struct node 
{
    int data;
    struct node * next;
};

void Display(PNODE Head)
{

}

int Count (PNODE Head)
{
    return 0;
}

void InsertFrist(PPNODE Head, int No)
{

}

void InsertLast(PPNODE Head, int No)
{

}

void InsertAtPos(PPNODE Head, int No, int Pos)
{

}

void DeleteFrist(PPNODE Head)
{

}

void DeleteLast(PPNODE Head)
{

}

void DeleteAtPos(PPNODE Head, int Pos)
{

}

int main()
{
    PNODE Frist = NULL;
       
    return 0;
}