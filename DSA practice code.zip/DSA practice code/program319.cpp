/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 29/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : C++ language DSA DoublyCL new approch
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef class node
{
    public:
        int data;
        node * next;
        node * prev;

        node()
        {
            data = 0;
            next = NULL;
            prev = NULL;
        }

        node(int value)
        {
            data = value;
            next = NULL;
            prev = NULL;
        }
}NODE, *PNODE;

class LinkedList
{
    public:
        PNODE Frist;
        int iCount;

        LinkedList()
        {
            Frist = NULL;
            iCount = 0;
        }

        virtual void InsertFrist(int iNo) = 0;
        virtual void InsertLast(int iNo) = 0;
        virtual void InsertAtPos(int iNo, int iPos) = 0;

        virtual void DeleteFrist() = 0;
        virtual void DeleteLast() = 0;
        virtual void DeleteAtPos(int iPos) = 0;

        void Display()
        {
            PNODE temp = Frist;

            for(int iCnt = 1; iCnt <= iCount; iCnt++)
            {
                cout << "| "<< temp -> data << "| " "-> ";
                temp = temp -> next;
            }
            cout << "NULL" << "\n";
        }

        int Count()
        {
            return iCount;
        }
};

class DoublyCL : public LinkedList
{
    private:
        PNODE Last;
    
    public:
        DoublyCL();
        ~DoublyCL();

        void InsertFrist(int iNo);
        void InsertLast(int iNo);
        void InsertAtPos(int iNo, int iPos);

        void DeleteFrist();
        void DeleteLast();
        void DeleteAtPos(int iPos);

};

DoublyCL :: DoublyCL()
{
    Last = NULL;
} 

DoublyCL :: ~DoublyCL()
{

}

void DoublyCL :: InsertFrist(int iNo)
{
    PNODE newn = new NODE(iNo);

    /*
        PNODE  newn = new NODE;
        newn -> data = iNo;
        nwen -> next = NULL;
        newn -> prev = NULL;
    */

   if(Frist == NULL && Last == NULL)
   {
        Frist = newn;
        Last = newn;
   }

   else
   {
        newn -> next = Frist;
        Frist -> prev = newn;
        Frist = newn;
   }
   Last -> next = Frist;
   Frist -> prev = Last;
   iCount++;
}
void DoublyCL :: InsertLast(int iNo)
{
    PNODE newn = new NODE(iNo);

    /*
        PNODE  newn = new NODE;
        newn -> data = iNo;
        nwen -> next = NULL;
        newn -> prev = NULL;
    */

   if(Frist == NULL && Last == NULL)
   {
        Frist = newn;
        Last = newn;
   }

   else
   {
        Last -> next = newn;
        newn -> prev = Last;
        Last = Last -> next;
   }
   Last -> next = Frist;
   Frist -> prev = Last;
   iCount++;
}


void DoublyCL :: DeleteFrist()
{
    if(iCount == 0)     // empty
    {
        return ;
    }
    else if(iCount == 1)    // one node
    {
        delete Frist;
        Frist = NULL;
        Last = NULL;
    }
    else        // more than one node
    {
        Frist = Frist -> next;
        delete Last -> next;    // delete frist -> prev;

        Frist -> prev = Last;
        Last -> next = Frist;
    }

    iCount --;
}
void DoublyCL :: DeleteLast()
{
    if(iCount == 0)     // empty
    {
        return ;
    }
    else if(iCount == 1)    // one node
    {
        delete Frist;
        Frist = NULL;
        Last = NULL;
    }
    else        // more than one node
    {
        Last = Last -> prev;
        delete Last -> next;

        Frist -> prev = Last;
        Last -> next = Frist;
    }

    iCount --;
}

void DoublyCL :: InsertAtPos(int iNo, int iPos)
{
    PNODE temp = Frist;
    
    if((iPos < 1) || ( iPos > iCount+1))
    {
        cout << "Invalid";
        return ;
    }

    if(iPos == 1)
    {
        InsertFrist(iNo);
    }
    else if(iPos == iCount + 1)
    {
        InsertLast(iNo);
    }
    else
    {
        PNODE temp = Frist;

        for(int iCnt = 1; iCnt < iPos - 1; iCnt++)
        {
            temp = temp -> next;
        }
    }

    PNODE newn = new NODE(iNo);

    newn -> next = temp -> next;
    temp -> next -> prev = newn;

    temp -> next = newn;
    newn -> prev = temp;

    iCount++;
}

void DoublyCL :: DeleteAtPos(int iPos)
{
    if((iPos < 1) || ( iPos > iCount))
    {
        cout << "Invalid";
        return ;
    }

    if(iPos == 1)
    {
        DeleteFrist();
    }
    else if(iPos == iCount)
    {
        DeleteLast();
    }
    else
    {
        PNODE temp = Frist;

        for(int iCnt = 1; iCnt < iPos - 1; iCnt++)
        {
            temp = temp -> next;
        }

        temp -> next = temp -> next -> next;
        delete temp -> next -> prev;
        temp -> next -> prev;

        iCount--;  
    }
}


int main()
{
    DoublyCL obj;

    obj.InsertFrist(51);
    obj.InsertFrist(21);
    obj.InsertFrist(11);

    obj.InsertLast(101);
    obj.InsertLast(111);

    obj.Display();
    cout << "Length of Linked List is : " << obj.Count() << "\n";

    obj.InsertAtPos(55, 4);

    obj.Display();
    cout << "Length of Linked List is : " << obj.Count() << "\n";

    obj.DeleteAtPos(4);

    obj.Display();
    cout << "Length of Linked List is : " << obj.Count() << "\n";

    obj.DeleteFrist();
    obj.DeleteLast();

    obj.Display();
    cout << "Length of Linked List is : " << obj.Count() << "\n";

    return 0;
}