/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 20/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Dubbly LinkedList 
//
/////////////////////////////////////////////////////////////

#include<stdio.h> 
#include<stdlib.h>

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;

struct Node
{
    int data ;
    struct Node *next;
    struct Node *prev;  // #
};

int main()
{
    PNODE Frist = NULL;

    return 0;
}