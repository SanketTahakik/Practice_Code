/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 12/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Logic Display, Count, InsertFrist, InsertLast
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h> // malloc and free

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;

struct Node
{
    int data;
    struct Node *next;
};


void InsertFrist(PPNODE Head, int No)
{
    PNODE newn = NULL;

    // Allocate memory for node
    newn = (PNODE)malloc(sizeof(NODE));
 // newn = (struct Node*)malloc(sizeof(struct Node))

    // Initialise the node
    newn->data = No;
    newn->next = NULL;

    if(*Head == NULL)    // LL is empty
    {
        *Head = newn;
    }
    else    // LL contain at least one ni=ode
    {
        newn -> next = *Head;
        *Head = newn;
    }
}

void InsertLast(PPNODE Head, int No)
{
    PNODE newn = NULL;

    // Allocate memory for node
    newn = (PNODE)malloc(sizeof(NODE));
 // newn = (struct Node*)malloc(sizeof(struct Node))

    // Initialise the node
    newn->data = No;
    newn->next = NULL;

    if(*Head == NULL)    // LL is empty
    {
        *Head = newn;
    }
    else    // LL contain at least one ni=ode
    {
        
    }

}

void Display(PNODE Head)
{
    while(Head != NULL)
    {
        printf("|%d| -> ", Head -> data);
        Head = Head -> next;
    }
    printf("NULL\n");
}

int Count (PNODE Head)
{
    int iCount = 0;
    while(Head != NULL)
    {
        iCount++;
        Head = Head -> next;
    }

    return iCount;
}

int main()
{
    PNODE Frist = NULL;
    int iRet = 0;

    InsertFrist(&Frist, 111);    //InsertFrist(60, 111)
    InsertFrist(&Frist, 101);    //InsertFrist(60, 101)
    InsertFrist(&Frist, 51);    //InsertFrist(60, 51)
    InsertFrist(&Frist, 21);    //InsertFrist(60, 21)
    InsertFrist(&Frist, 11);    //InsertFrist(60, 11)
    
    Display(Frist);

    iRet = Count(Frist);

    printf("%d\n", iRet);
    return 0;
}