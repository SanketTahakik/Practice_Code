/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 20/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Dubbly LinkedList InsertFrist, InsertLast, Display, Count
//
/////////////////////////////////////////////////////////////

#include<stdio.h> 
#include<stdlib.h>

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;

struct Node
{
    int data ;
    struct Node *next;
    struct Node *prev;    // #
};

void InsertFrist(PPNODE Head, int iNo)
{
    PNODE newn = NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn -> data = iNo;
    newn -> next = NULL;
    newn -> prev = NULL;    // #

    if(*Head == NULL)
    {
        *Head = newn;
    }
    else
    {
        (*Head) -> prev = newn;     // #
        newn -> next = *Head;
        *Head = newn;
    }
}

void InsertLast(PPNODE Head, int iNo)
{
    PNODE newn = NULL;

    newn = (PNODE)malloc(sizeof(NODE));

    newn -> data = iNo;
    newn -> next = NULL;
    newn -> prev = NULL;    // #

    if(*Head == NULL)
    {
        *Head = newn;
    }
    else
    {
        
    }
}

void InsertAtPos(PPNODE Head, int iNo, int iPos)
{

}

void DeleteFrist(PPNODE Head)
{
    
}

void DeleteLast(PPNODE Head)
{

}

void DeleteAtPos(PPNODE Head, int iPos)
{

}

int Count(PNODE Head)
{
    int iCount = 0;

    while(Head != NULL)
    {
        iCount++;
        Head = Head -> next;
    }

    return iCount;
}

void Display(PNODE Head)
{
    printf("Elemets of linkedlist are : \n");

    printf("NULL <=> ");
    while(Head != NULL)
    {
        printf("| %d | <=> ", Head-> data);
        Head = Head -> next;
    }
    printf("NULL \n");
}


int main()
{
    PNODE Frist = NULL;
    int iRet = 0;

    InsertFrist(&Frist, 101);
    InsertFrist(&Frist, 51);
    InsertFrist(&Frist, 21);
    InsertFrist(&Frist, 11);
    
    iRet = Count(Frist);
    printf("Number of element are : %d\n", iRet);

    Display(Frist);

    return 0;
}