/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 29/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : C++ language DSA
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef struct node
{
    int data;
    struct node * next;
}NODE, *PNODE, **PPNODE;

class SinglyLL
{
    private:
        PNODE Frist;    // characteristics
    
        int iCount;     // characteristics

    public:

        SinglyLL();
        ~SinglyLL();

        void InsertFrist(int iNo);
        void InsertLast(int iNo);
        void InsertAtPos(int iNo, int iPos);

        void DeleteFrist();
        void DeleteLast();
        void DeleteAtPos(int iPos);

        void Display();
        int Count();
};

// Implimentation of all behaviours

/*
    Return_value Class_Name :: Function_Name(Parametetr_List)
    {
        Function_Body;
    }
*/

void SinglyLL :: InsertFrist(int iNo)
{
    PNODE newn = NULL;
    newn = new NODE;    // newn = (PNODE)malloc(sizeof(NODE));

    newn -> data = iNo;
    newn -> next = NULL;

    if(Frist == NULL)   // LL is empty
    {
        Frist = newn;
    }
    else    // LL contain at leat one node in it
    {
        newn -> next = Frist;
        Frist = newn;
    }
    iCount++;
}


void SinglyLL :: InsertLast(int iNo)
{
    PNODE newn = NULL;
    newn = new NODE;    // newn = (PNODE)malloc(sizeof(NODE));

    newn -> data = iNo;
    newn -> next = NULL;

    if(Frist == NULL)   // LL is empty
    {
        Frist = newn;
    }
    else    // LL contain at leat one node in it
    {
        PNODE temp = Frist;

        while(temp -> next != NULL)
        {
            temp = temp -> next ;
        }
        temp -> next = newn;
    }
    iCount++;
}

void SinglyLL :: InsertAtPos(int iNo, int iPos)
{

}

void SinglyLL :: DeleteFrist()
{

}
void SinglyLL :: DeleteLast()
{

}
void SinglyLL :: DeleteAtPos(int iPos)
{

}

void SinglyLL :: Display()
{
    PNODE temp = Frist;

    cout << "Element of LL are : " << "\n";

    while(temp != NULL)
    {
        cout << " | " << temp -> data <<  " |-> ";
        temp = temp -> next;
    }
    cout << "NULL"<< "\n";
}

int SinglyLL :: Count()
{
    return iCount;
}

SinglyLL :: SinglyLL()
{
    cout << "Inside Constructor\n";

    Frist = NULL;
    iCount = 0;
}

SinglyLL :: ~SinglyLL()
{
    cout << "Inside Distructor\n";
}

/////////////////////////////////////////////////////////////////////


int main()
{
    int iRet = 0;
    SinglyLL obj1;
    SinglyLL obj2;

    obj1.InsertFrist(51);
    obj1.InsertFrist(21);
    obj1.InsertFrist(11);

    obj1.InsertLast(101);
    obj1.InsertLast(111);

    obj1.Display();
    iRet = obj1.Count();

    cout <<"Number of element area : " << iRet << "\n";

    obj2.InsertFrist(30);
    obj2.InsertFrist(20);
    obj2.InsertFrist(10);

    obj1.Display();
    iRet = obj2.Count();

    cout <<"Number of element area : " << iRet << "\n";

    // cout << "Size of LL is :" << obj1.iCount;  //Error

    return 0;
}