/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 13/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Display, Count, InsertFrist and InsertLast, DeleteFrist, DeleteLast, InserAtPos, DeleteAtPos
//
/////////////////////////////////////////////////////////////
#include<stdio.h>
#include<stdlib.h>

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;

struct Node
{
    int data;
    struct Node * next;
};


// 1: Allocate memory for Node
// 2: Initalise the Node
// 3: Check whether LL is empty of Not
// 4: If LL is empty store address of newNode in Frist
// 5: Otherwise store the address of newNode nside next pointer of old node
// 6: Update frist pointer with the address of new node

void InsertFrist(PPNODE Head, int iNo)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // 1

    newn -> data = iNo; // 2
    newn -> next = NULL;    

    if(*Head == NULL)   // 3
    {
        *Head = newn;
    }
    else    // 4
    {
        newn -> next = *Head;   // 5
        *Head = newn;   //6
    }
}

void InsertLast(PPNODE Head, int iNo)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // 1

    PNODE temp = *Head;
    newn -> data = iNo; // 2
    newn -> next = NULL;    

    if(*Head == NULL)   // 3
    {
        *Head = newn;
    }
    else    // 4
    {
        while (temp -> next != NULL)
        {
            temp = temp -> next;
        }
        temp -> next = newn;
        
    }

}

void Display(PNODE Head)
{
    printf("Element of LinkedList are : \n");

    while (Head != NULL)
    {
        printf("|%d| ->", Head->data);
        Head = Head -> next;
    }
    printf("NULL \n");
    
}

int Count(PNODE Head)
{
    int iCount = 0;

    while (Head != NULL)
    {
        iCount++;
        Head = Head -> next;
    }
    return iCount;
}

void DeleteFrist(PPNODE Head)
{
    PNODE temp = *Head;

    if(*Head == NULL)   // LL is Empty
    {
        return;
    }
    else if((*Head) -> next == NULL)    // LL contain one node
    {
        free(*Head);
        *Head = NULL;
    }
    else    // LL contain more than one node
    {
        *Head = (*Head) -> next;
        free(temp);
    }
}

void DeleteLast(PPNODE Head)
{
    PNODE temp = *Head;

    if(*Head == NULL)   // LL is Empty
    {
        return;
    }
    else if((*Head) -> next == NULL)    // LL contain one node
    {
        free(*Head);
        *Head = NULL;
    }
    else    // LL contain more than one node
    {
        while(temp -> next -> next != NULL)
        {
            temp = temp -> next;
        }
        free(temp -> next);
        temp -> next = NULL;
    }
}

void InsertAtPos(PPNODE Head, int iNo, int iPos)
{
    int iLength = 0;
    iLength = Count(*Head);     // Calculet length of LL
    PNODE temp = *Head;

    PNODE newn = NULL;

    // Filter
    if((iPos < 1) || (iPos > iLength + 1))  // Invalid position
    {
        printf("Invalid Position\n");
        return;
    }
    // InsertFrist
    if( iPos == 1)
    {
        InsertFrist(Head, iNo);
    }
    // InsertLast
    else if(iPos == iLength)
    {
        InsertLast(Head, iNo);
    }

    else
    {
        newn = (PNODE)malloc(sizeof(NODE));

        newn -> data = iNo; 
        newn -> next = NULL;    

        for(int iCnt = 1; iCnt < iPos - 1; iCnt++)
        {
            temp = temp -> next;
        }

        newn -> next = temp -> next;
        temp -> next = newn;
    }
}

void DeleteAtPos(PPNODE Head, int iPos)
{
    int iLength = 0;
    PNODE temp = *Head;
    PNODE tempX = *Head;
    iLength = Count(*Head);     // Calculet length of LL
    // Filter
    if((iPos < 1) || (iPos > iLength))  // Invalid position
    {
        printf("Invalid Position\n");
        return;
    }
    // InsertFrist
    if( iPos == 1)
    {
        DeleteFrist(Head);
    }
    // InsertLast
    else if(iPos == iLength)
    {
        DeleteLast(Head);
    }

    else
    {
        
    }
}


int main()
{
    PNODE Frist = NULL;
    int iRet = 0;

    InsertLast(&Frist, 11);
    InsertLast(&Frist, 21);
    InsertLast(&Frist, 51);
    InsertLast(&Frist, 101);

    Display(Frist);

    iRet = Count(Frist);

    printf("Number of node are : %d \n", iRet);

    InsertFrist(&Frist, 10);
    InsertFrist(&Frist, 20);

    InsertAtPos(&Frist, 25, 5);

    Display(Frist);

    iRet = Count(Frist);

    printf("Number of node are : %d \n", iRet);

    DeleteFrist(&Frist);
    DeleteFrist(&Frist);

    Display(Frist);

    iRet = Count(Frist);

    printf("Number of node are : %d \n", iRet);

    DeleteLast(&Frist);

    Display(Frist);

    iRet = Count(Frist);

    printf("Number of node are : %d \n", iRet);


    return 0;
}