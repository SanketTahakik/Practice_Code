/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 29/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : C++ language DSA DoublyCL
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef struct node
{
    int data;
    struct node * next;
    struct node * prev;
}NODE, *PNODE;

class DoublyCL
{
    private:
        PNODE Frist;
        PNODE Last;
        int iCount ;
    
    public:
        DoublyCL();
        ~DoublyCL();

        void InsertFrist(int iNo);
        void InsertLast(int iNo);
        void InsertAtPos(int iNo, int iPos);

        void DeleteFrist();
        void DeleteLast();
        void DeleteAtPos(int iPos);

        void Display();
        int Count();
};


int main()
{


    return 0;
}