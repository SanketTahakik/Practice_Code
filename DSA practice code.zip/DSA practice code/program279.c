/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 13/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Revision Logic Display, Count, InsertFrist and InsertLast
//
/////////////////////////////////////////////////////////////
#include<stdio.h>
#include<stdlib.h>

typedef struct Node NODE;
typedef struct Node* PNODE;
typedef struct Node** PPNODE;

struct Node
{
    int data;
    struct Node * next;
};


// 1: Allocate memory for Node
// 2: Initalise the Node
// 3: Check whether LL is empty of Not
// 4: If LL is empty store address of newNode in Frist
// 5: Otherwise store the address of newNode nside next pointer of old node
// 6: Update frist pointer with the address of new node

void InsertFrist(PPNODE Head, int iNo)
{
    PNODE newn = NULL;
    newn = (PNODE)malloc(sizeof(NODE)); // 1

    newn -> data = iNo; // 2
    newn -> next = NULL;    

    if(*Head == NULL)   // 3
    {
        *Head = newn;
    }
    else    // 4
    {
        newn -> next = *Head;   // 5
        *Head = newn;   //6
    }
}

void Display(PNODE Head)
{
    printf("Element of LinkedList are : \n");

    while (Head != NULL)
    {
        printf("|%d| ->", Head->data);
        Head = Head -> next;
    }
    printf("NULL \n");
    
}

int main()
{
    PNODE Frist = NULL;

    InsertFrist(&Frist, 111);
    InsertFrist(&Frist, 101);
    InsertFrist(&Frist, 51);
    InsertFrist(&Frist, 21);
    InsertFrist(&Frist, 11);

    Display(Frist);

    return 0;
}