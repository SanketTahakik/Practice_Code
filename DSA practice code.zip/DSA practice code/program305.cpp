/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 29/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : C++ language DSA
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef struct node
{
    int data;
    struct node * next;
}NODE, *PNODE, **PPNODE;

class SinglyLL
{
    private:
        PNODE Frist;    // characteristics
    
        int iCount;     // characteristics

    public:

        SinglyLL();

        void InsertFrist(int iNo);
        void InsertLast(int iNo);
        void InsertAtPos(int iNo, int iPos);

        void DeleteFrist();
        void DeleteLast();
        void DeleteAtPos(int iPos);

        void Display();
        int Count();
};

// Implimentation of all behaviours

/*
    Return_value Class_Name :: Function_Name(Parametetr_List)
    {
        Function_Body;
    }
*/

void SinglyLL :: InsertFrist(int iNo)
{
    
}
void SinglyLL :: InsertLast(int iNo)
{

}
void SinglyLL :: InsertAtPos(int iNo, int iPos)
{

}

void SinglyLL :: DeleteFrist()
{

}
void SinglyLL :: DeleteLast()
{

}
void SinglyLL :: DeleteAtPos(int iPos)
{

}

void SinglyLL :: Display()
{

}

int SinglyLL :: Count()
{
    return 0;
}

SinglyLL :: SinglyLL()
{
    cout << "Inside Constructor\n";

    Frist = NULL;
    iCount = 0;
}

/////////////////////////////////////////////////////////////////////


int main()
{
    SinglyLL obj1;
    SinglyLL obj2;

    // cout << "Size of LL is :" << obj1.iCount;  //Error

    return 0;
}