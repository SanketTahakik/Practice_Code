/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 29/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : C++ language DSA
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef class node
{
    public:
        int data;
        node * next;
        
        node(int value)
        {
            data = value;
            next = NULL;
        }

}NODE, *PNODE;

class Stack
{
    private:
        PNODE Frist;
        int iCount = 0;
    
    public:
        Stack();
        void Push(int iNo);     // insert
        int Pop();              // delete
        void Display();
        int Count();
};

Stack :: Stack()
{

}
void Stack :: Push(int iNo)
{
    PNODE newn = new NODE(iNo);

    if(Frist == NULL)
    {
        Frist = newn;
    }
    else
    {
        PNODE temp = Frist;

        while(temp -> next != NULL)
        {
            temp = temp -> next;
        }
        temp -> next = newn;
    }
    iCount++;
}  

int Stack :: Pop()      // DeleteFrist
{
    int Value = 0;

    if(iCount == 0)
    {
        cout << "Stack is empty";
        return -1;
    }
    else if(iCount == 1)
    {
        Value = Frist ->data;
        delete Frist;
        Frist = NULL;
    }
    else
    {
        PNODE temp = Frist;

        while(temp -> next -> next != NULL)
        {
            temp = temp -> next;
        }
        
        Value = temp -> next -> data;
        delete temp -> next;
        temp -> next = NULL;
    }
    iCount--;
    return Value;
} 

void Stack :: Display()
{
    cout << "Element of stack are :";

    PNODE temp = Frist;

    for(int iCnt = 1; iCnt < iCount; iCnt++)
    {
        cout << temp -> data<< "\n";
        temp = temp -> next;
    }
}
int Stack :: Count()
{
    return iCount;
}

int main()
{


    return 0;
}