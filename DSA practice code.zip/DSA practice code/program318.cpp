/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 29/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : C++ language DSA DoublyCL new approch
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef class node
{
    public:
        int data;
        node * next;
        node * prev;

        node()
        {
            data = 0;
            next = NULL;
            prev = NULL;
        }

        node(int value)
        {
            data = value;
            next = NULL;
            prev = NULL;
        }
}NODE, *PNODE;

class LinkedList
{
    public:
        PNODE Frist;
        int iCount;

        LinkedList()
        {
            Frist = NULL;
            iCount = 0;
        }

        virtual void InsertFrist(int iNo) = 0;
        virtual void InsertLast(int iNo) = 0;
        virtual void InsertAtPos(int iNo, int iPos) = 0;

        virtual void DeleteFrist() = 0;
        virtual void DeleteLast() = 0;
        virtual void DeleteAtPos(int iPos) = 0;

        void Display()
        {
            PNODE temp = Frist;

            for(int iCnt = 1; iCnt <= iCount; iCnt++)
            {
                cout << "| "<< temp -> data << "| " "-> ";
                temp = temp -> next;
            }
            cout << "NULL" << "\n";
        }

        int Count()
        {
            return iCount;
        }
};

class DoublyCL : public LinkedList
{
    private:
        PNODE Last;
    
    public:
        DoublyCL();
        ~DoublyCL();

        void InsertFrist(int iNo);
        void InsertLast(int iNo);
        void InsertAtPos(int iNo, int iPos);

        void DeleteFrist();
        void DeleteLast();
        void DeleteAtPos(int iPos);

};

DoublyCL :: DoublyCL()
{
    Last = NULL;
} 

DoublyCL :: ~DoublyCL()
{

}

void DoublyCL :: InsertFrist(int iNo)
{
    PNODE newn = new NODE(iNo);

    /*
        PNODE  newn = new NODE;
        newn -> data = iNo;
        nwen -> next = NULL;
        newn -> prev = NULL;
    */

   if(Frist == NULL && Last == NULL)
   {
        Frist = newn;
        Last = newn;
   }

   else
   {
        newn -> next = Frist;
        Frist -> prev = newn;
        Frist = newn;
   }
   Last -> next = Frist;
   Frist -> prev = Last;
   iCount++;
}
void DoublyCL :: InsertLast(int iNo)
{
    PNODE newn = new NODE(iNo);

    /*
        PNODE  newn = new NODE;
        newn -> data = iNo;
        nwen -> next = NULL;
        newn -> prev = NULL;
    */

   if(Frist == NULL && Last == NULL)
   {
        Frist = newn;
        Last = newn;
   }

   else
   {
        Last -> next = newn;
        newn -> prev = Last;
        Last = Last -> next;
   }
   Last -> next = Frist;
   Frist -> prev = Last;
   iCount++;
}
void DoublyCL :: InsertAtPos(int iNo, int iPos)
{

}

void DoublyCL :: DeleteFrist()
{

}
void DoublyCL :: DeleteLast()
{

}
void DoublyCL :: DeleteAtPos(int iPos)
{

}


int main()
{
    DoublyCL obj;

    obj.InsertFrist(51);
    obj.InsertFrist(21);
    obj.InsertFrist(11);

    obj.InsertLast(101);
    obj.InsertLast(111);

    obj.Display();
    cout << "Length of Linked List is : " << obj.Count() << "\n";

    return 0;
}