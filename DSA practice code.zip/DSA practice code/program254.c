/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : DSA
// Auther        : Tahakik Sanket Rajendra
// Date          : 12/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Define structure
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h> // malloc and free

typedef struct node NODE;
typedef struct node* PNODE;
typedef struct node** PPNODE;

struct Node
{
    int no;
    struct Node *next;
};


int main()
{
    PNODE Frist = NULL;
    
    
    return 0;
}