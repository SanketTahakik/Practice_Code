/////////////////////////////////////////////////////////////
//
// Function name : CheckDigits
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String for user and calculet small charator
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>

int strlenSmallX(char *str)
{
    int iCount = 0;

    while (*str != '\0')
    {
        if((*str >= 'a') && (*str <= 'z'))
        {
            iCount++;
        }
        str++;
    }
    return iCount;
    
}

int main()
{
    char Arr[20];
    int iRet = 0;

    printf("Enter String :\n");
    scanf("%[^'\n']s", Arr); 

    iRet = strlenSmallX(Arr);

    printf("Length of string is : %d",iRet);

   return 0;
}
