/////////////////////////////////////////////////////////////
//
// Function name : strcpySmallX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the String and copied to another string only small letter 
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

void strcpySmallX(char *src, char *dest)
{
    while(*src != '\0')
    {
        if(*src >= 'a' && *src <= 'z')
        {
            *dest = *src;
            dest++;
        }
        src++;
    }
    *dest = '\0';
}

int main()
{
    char Arr[20] ;
    char Brr[20];

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    strcpySmallX(Arr,Brr);

    printf("String after copy is %s\n",Brr);
    
    return 0;
}
