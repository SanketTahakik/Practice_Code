/////////////////////////////////////////////////////////////
//
// Function name : CountSpace
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String for user and calculet Space
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>

int CountSpace(char *str)
{
    int iCount = 0;

    while (*str != '\0')
    {
        if(*str == ' ')
        {
            iCount++;
        }
        str++;
    }
    return iCount;
    
}

int main()
{
    char Arr[20];
    int iRet = 0;

    printf("Enter String :\n");
    scanf("%[^'\n']s", Arr); 

    iRet = CountSpace(Arr);

    printf("Length of Speces are : %d",iRet);

   return 0;
}
