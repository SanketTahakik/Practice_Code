/////////////////////////////////////////////////////////////
//
// Function name : CalculetPower
// input         : integer
// Output        : integer
// Discption     : Calculet the x^y , x is 2 and y is 3 is equal to 8, use of While loop
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Calculet the x^y 
//
/////////////////////////////////////////////////////////////

/*
    x = 2;
    y = 3;
    2 * 2 * 2 = 8;
*/


#include<stdio.h>
#include<stdbool.h>

int CalulatePower(int iNo1, int iNo2)
{
    int iResult = 1;
    int iCnt = 0;
    
    iCnt = 1;
    while( iCnt <= iNo2)
    {
        iResult = iResult * iNo1;
        iCnt++;
    }
    return iResult;
}

int main()
{
    int iValue1 = 0, iValue2 = 0;
    int iRet = 0;

    printf("Enter the base : \n");
    scanf("%d", &iValue1);
    printf("Enter the power : \n");
    scanf("%d", &iValue2);

    iRet = CalulatePower(iValue1,iValue2);

    printf("reuslt is : %d\n", iRet);
    return 0;
}