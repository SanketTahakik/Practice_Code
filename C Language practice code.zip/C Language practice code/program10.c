/////////////////////////////////////////////////////////////
//
// Function name : use of for loop
// input         : integer
// Output        : integer
// Discption     : how to use of for loop
// Auther        : Tahakik Sanket Rajendra
// Date          : 26/04/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display Jay Ganesh in 5 time on screen
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int main()
{
    int iCnt = 0;
    //    1           2         3
    for(iCnt = 0; iCnt <= 5; iCnt ++)
    {
        printf("Jay Ganesh....\n");      //4
    }    

    return 0;
}