/////////////////////////////////////////////////////////////
//
// Function name : Display
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : ASCII table
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>

int main()
{
   int iCnt = 0;
   
   printf("ASCII Table\n");
   
   for(iCnt = 0; iCnt <= 127; iCnt++)
   {
    printf("%c\t%d\n",iCnt,iCnt);
   }

   return 0;

}
