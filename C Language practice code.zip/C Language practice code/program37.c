/////////////////////////////////////////////////////////////
//
// Function name : DisplayF
// input         : integer
// Output        : integer
// Discption     : Print the forworld number 1 2 3 4 5 6...
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Print the forworld number
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

void DisplayF(int iNo)
{
    for(int iCnt = 1; iCnt <= iNo; iCnt++)
    {
        printf("%d \t",iCnt);
    }
}

int main()
{
    int iValue = 0;
    printf("Enter the number :");
    scanf("%d", &iValue);

    DisplayF(iValue);

    return 0;   
}