/////////////////////////////////////////////////////////////
//
// Function name : CheckPallidrome
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 23/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the String and whethe string are palidroom
//
/////////////////////////////////////////////////////////////

/*
    str1  nayan
    str2  nayan

    str1  najan
    str2  najan
*/

#include<stdio.h>
#include<stdbool.h>

bool CheckPallidrome(char *str)
{
    char *start = NULL;
    char *end = NULL;
    bool bFlag = true;

    start = str;
    end = str;

    while(*end != '\0')
    {
        end++;
    }
    end--;

    while(start < end)
    {
        if(*start != *end)
        {
            bFlag = false;
            break;
        }
        start++;
        end--;
    }
    return bFlag;
}

int main()
{
    char Arr[20] ;
    bool bRet = false;

    printf("Revers string is : \n");
    scanf("%[^'\n']s",Arr);

    bRet = CheckPallidrome(Arr);

    if(bRet == true)
    {
        printf("String is pallindrom\n");
    }
    else
    {
        printf("String is not a pallindrom\n");
    }
    
    return 0;
}
