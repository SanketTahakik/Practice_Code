/////////////////////////////////////////////////////////////
//
// Function name : CountDigits
// input         : integer
// Output        : integer
// Discption     : Accept two number form user and check count of second number
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept two number form user and check count of second number
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

int CountDigits(int iNo1 , int iNo2)
{
    int iDigit = 0;
    int iSum = 0;

    while(iNo1 != 0)
    {
        iDigit = iNo1 % 10;

        if(iDigit == iNo2)
        {
           iSum = iSum + 1;            
        }
        iNo1 = iNo1 / 10;
    } 
    return iSum;

}

int main()
{
    int iValue1 = 0;
    int iValue2 = 0;
    int iRet = 0;

    printf("Enter the number \n");
    scanf("%d", &iValue1);
    printf("Enter the Digit(0 to 9) \n");
    scanf("%d", &iValue2);

    iRet = CountDigits(iValue1, iValue2);
    
    printf("%d", iRet);

    return 0;
}