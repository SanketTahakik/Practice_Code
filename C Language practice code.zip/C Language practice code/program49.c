/////////////////////////////////////////////////////////////
//
// Function name : CountDigits
// input         : integer
// Output        : integer
// Discption     : print given number count, use of While loop
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  print given number count.
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int CountDigits(int iNo)
{
    int iCnt = 0;

    while (iNo != 0)
    {
        iCnt++;
        iNo = iNo / 10;
    }
    return iCnt;
}
int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number : ");
    scanf ("%d", &iValue);

    iRet = CountDigits(iValue);
    printf("number in digits are : %d",iRet);

    return 0 ;
}


