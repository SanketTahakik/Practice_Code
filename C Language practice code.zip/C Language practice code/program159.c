/////////////////////////////////////////////////////////////
//
// Function name : CheckDigits
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept character for user and print the length of string
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>
#include<string.h>

int strlenX(char str[])
{

}

int main()
{
    char Arr[20];
    int iRet = 0;

    printf("Enter String :\n");
    scanf("%[^'\n']s", Arr); 

    iRet = strlen(Arr);

    printf("Length of  string is : %d",iRet);

   return 0;
}
