/////////////////////////////////////////////////////////////
//
// Function name : Minimum
// input         : integer
// Output        : integer
// Discption     : Find the Minimum number in array.
// Auther        : Tahakik Sanket Rajendra
// Date          : 14/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Find the Minimum number in array.
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>

int MinDispaly(int Arr[], int iLength)
{
    int iCnt = 0;
    int iMin = Arr[0];

    for (iCnt = 0; iCnt < iLength; iCnt++)
    {
        if(Arr[iCnt] < iMin);
        {
            iMin = Arr[iCnt];
        }
    }
    return iMin;
    
}

int main()
{
    int iSize = 0;
    int *ptr = NULL;
    int iRet = 0;

    printf("Enter the size : ");
    scanf("%d",&iSize);

    ptr = (int *)malloc(iSize * sizeof(int));

    printf("Enter the value :\n");
    for (int iCnt = 0; iCnt < iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    printf("Your Enter the value :\n");
    for (int iCnt = 0; iCnt < iSize; iCnt++)
    {
        printf("%d\n",ptr[iCnt]);
    }

    iRet = MinDispaly(ptr , iSize);

    printf("Minimum number is : %d", iRet);
    
    free(ptr);

    return 0;
}