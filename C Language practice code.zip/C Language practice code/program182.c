/////////////////////////////////////////////////////////////
//
// Function name : strtoggleX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Find and replace Small with Capital and Caprital to Small
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

void strtoggleX(char *str)
{
    int Gap = 'a' - 'A';
    while(*str != '\0')
    {
        if(*str >= 'a' && *str <= 'z'  )
        {
            *str = *str - Gap;
        }
        else if(*str >= 'A' && *str <= 'Z'  )
        {
            *str = *str + Gap;
        }
        str++;
    }
}

int main()
{
    char Arr[20] ;

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    strtoggleX(Arr);

    printf("String after editing is %s\n",Arr);
    
    return 0;
}
