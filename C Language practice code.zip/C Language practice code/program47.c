/////////////////////////////////////////////////////////////
//
// Function name : DisplayDigits
// input         : integer
// Output        : integer
// Discption     : print given number in separete, use of While loop
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  print given number in separete
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

void DisplayDigits(int iNo)
{
    int iDigits = 0;

    while (iNo != 0)
    {
        iDigits = iNo % 10;
        printf("%d\n",iDigits);
        iNo = iNo / 10;
    }
    
}
int main()
{
    int iValue = 0;

    printf("Enter the number : ");
    scanf ("%d", &iValue);

    DisplayDigits(iValue);

    return 0 ;
}

/*

iNo = 761;

iDigit = iNo % 10 ;         1
iNo = iNo / 10;             76

iDigit = iNo % 10 ;         6
iNo = iNo / 10;             7

iDigit = iNo % 10 ;         7
iNo = iNo / 10;             0


*/