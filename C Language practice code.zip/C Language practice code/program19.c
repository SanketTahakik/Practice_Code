/////////////////////////////////////////////////////////////
//
// Function name : Display
// input         : Integer
// Output        : Integer
// Discption     : Use of Filter
// Auther        : Tahakik Sanket Rajendra
// Date          : 26/04/2023
//
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display 1 to 5 on screen using function
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

void Display(int iNo)
{
    
///////////////////////////////////////////////////////////////
//
// Filter
//
///////////////////////////////////////////////////////////////
    if(iNo < 0)
    {
        printf("Invalid Input");
        return;
    }

    int iCnt = 0;
    for(iCnt = 1; iCnt <=iNo; iCnt++)
    {
        printf("%d \n", iCnt);
    }
}
int main()
{
    int iValue = 0;

    printf("Enter the frequency : \n");
    scanf("%d", &iValue);

    Display(iValue);

    return 0;
}