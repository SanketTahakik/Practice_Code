/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : 
// Auther        : Tahakik Sanket Rajendra
// Date          : 14/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : 
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdlib.h>

void fun(int Arr[], int iLength)
{

}

int main()
{
    int iSize = 0;
    int *ptr = NULL;

    printf("Enter the size : ");
    scanf("%d",&iSize);

    ptr = (int *)malloc(iSize * sizeof(int));

    printf("Enter the value :\n");
    for (int iCnt = 0; iCnt < iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    printf("Your Enter the value :\n");
    for (int iCnt = 0; iCnt < iSize; iCnt++)
    {
        printf("%d\n",ptr[iCnt]);
    }

    fun(ptr , iSize);
    
    free(ptr);

    return 0;
}