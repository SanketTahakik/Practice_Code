///////////////////////////////////////////////////////////////
// 
// Function name : Divideable 3 and 5
// Input         : Interger
// Output        : Boolen
// Description   : Check number is divisiable by 3 and 5
// Auther        : Sanket Rajendra Tahakik
// Date          : 25/04/2023
//
////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////
//
// Write a program which checks whether number is divisiable by 3 and 5
//
////////////////////////////////////////////////////////////////


#include<stdio.h>   // For printf or scanf
#include<stdbool.h> // For bool data type

bool CheckDivide3And5(int iNo)
{
    if(((iNo % 3) == 0) && ((iNo % 5)==0))
    {
        return true;
    }  
    else
    {
        return false;
    }      
}

///////////////////////////////////////////////////////////////
// Entry point
///////////////////////////////////////////////////////////////

int main()
{
    int iValue = 0;    // variable ti accept input
    bool bRet = false; // variable to accept return value

    printf("Please enter number to check whether it is divisible by 3 and 5 : ");
    scanf("%d" ,&iValue);

    bRet = CheckDivide3And5(iValue);  // Function call

    if (bRet == true)
    {
        printf("%d is completely divisible by 3 and 5 \n", iValue);
    }
    else
    {
        printf("%d is not completely divisible by 3 and 5 \n", iValue);
    }
    
    return 0;
}