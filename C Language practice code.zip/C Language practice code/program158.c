/////////////////////////////////////////////////////////////
//
// Function name : CheckDigits
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept character for user and check to Digits or not
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>

int main()
{
    char Arr[20];

    printf("Enter your name :\n");
    scanf("%[^'\n']s", Arr); 

    printf("your name is : %s",Arr);  

   return 0;
}
