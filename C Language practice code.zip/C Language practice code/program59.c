/////////////////////////////////////////////////////////////
//
// Function name : CountDigits
// input         : integer
// Output        : integer
// Discption     : Accept two number form user and check frist number in second number are present
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Accept two number form user and check frist number in second number are present
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdbool.h>

bool CountDigits(int iNo, int iSearch)
{
    int iDigit = 0;

    if(iSearch < 0 || iSearch > 9)
    {
        printf("Enter the digit in range 0 to 9");
        return false;
    }

    if(iNo < 0)
    {
        iNo = -iNo;
    }

    while (iNo != 0)
    {
        iDigit = iNo % 10 ;
        if(iDigit == iSearch)
        {
            break;
        }
        iNo= iNo /10;
    }
    if(iDigit == iSearch)
    {
        return true;
    }
    else
    {
        return false;
    }
    
}

int main()
{
    int iValue1 = 0;
    int iValue2 = 0;
    bool bRet = true;

    printf("Enter the number \n");
    scanf("%d", &iValue1);
    printf("Enter the Digit(0 to 9) \n");
    scanf("%d", &iValue2);

    bRet = CountDigits(iValue1, iValue2);
    printf("%d", bRet);

    if (bRet == true)
    {
        printf("%d is present in %d\n", iValue1, iValue2);
    }
    else
    {
        printf("%d is not present in %d\n", iValue1, iValue2);
    }
    
    return 0;
}