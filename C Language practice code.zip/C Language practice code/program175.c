/////////////////////////////////////////////////////////////
//
// Function name : Frequency
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String and character form user and return capital count and small letter count 
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#define ERR_NOTFOUND -1

void Frequency(char *str, char cValue)
{
    int iCnt1 = 0;
    int iCnt2 = 0;

    while (*str != '\0')
    {
        if(*str >= 'A' && *str <= 'Z')
        {
            iCnt1++;
        }
        else if(*str >= 'a' && *str <= 'z')
        {
            iCnt2++;
        }
        str++;
    }
    printf("%d\n",iCnt1);
    printf("%d\n",iCnt2);
}

int main()
{
    char Arr[20] ;
    char ch = '\0';
    int iRet = 0;

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    Frequency(Arr, ch);

    
    return 0;
}
