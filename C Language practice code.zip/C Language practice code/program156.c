/////////////////////////////////////////////////////////////
//
// Function name : CheckDigits
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept character for user and check to Digits or not
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>
#include<stdbool.h>

bool CheckDigit(char cValue)
{
    if((cValue >= '0') && (cValue <= '9'))
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
   char ch = '\0';
   bool bRet = false;

   printf("Enter the character :\n");
   scanf("%c",&ch);

   bRet = CheckDigit(ch);

    if(bRet == true)
    {
        printf("%c is a Digits \n",ch);
    }
    else
    {
        printf("%c is a not Digits \n",ch);
    }

   return 0;

}
