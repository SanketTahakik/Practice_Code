/////////////////////////////////////////////////////////////
//
// Function name : struprX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Find and replace Capital with Small
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

void struprX(char *str)
{
    while(*str != '\0')
    {
        if(*str >= 'a' && *str <= 'z'  )
        {
            *str = *str - 32;
        }
        str++;
    }
}

int main()
{
    char Arr[20] ;

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    struprX(Arr);

    printf("String after editing is %s\n",Arr);
    
    return 0;
}
