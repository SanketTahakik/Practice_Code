/////////////////////////////////////////////////////////////
//
// Function name : CheckDigits
// input         : integer
// Output        : integer
// Discption     : Accept the number and check in number 8 is present or not
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Accept the number and check in number 8 is present or not
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdbool.h>

bool CheckDigits(int iNo)
{
    int iDigit = 0;
    for(  ;iNo != 0; iNo = iNo / 10)
    {
        iDigit = iNo % 10;

        if(iDigit == 8)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

int main()
{
    int iValue = 0;
    bool iRet = true;
    printf("Enter the number \n");
    scanf("%d", &iValue);

    iRet = CheckDigits(iValue);

    if(iRet == true)
    {
        printf("8 is present ");
    }
    else{
        printf("8 is not present ");
    }
    return 0;
}