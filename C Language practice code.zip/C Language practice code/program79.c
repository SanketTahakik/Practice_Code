/////////////////////////////////////////////////////////////
//
// Function name : EvenCountDispay
// input         : integer
// Output        : integer
// Discption     : use of malloc
// Auther        : Tahakik Sanket Rajendra
// Date          : 10/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Accept n number from user and count the Even element 
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdlib.h> // memory management

int EvenCountDispay(int Arr[], int iLength)
{
    // Step5 = Perform the operation on array
    int iCounter = 0;
    
    for(int iCnt = 0; iCnt < iLength; iCnt++)
    {
        if ((Arr[iCnt] % 2) == 0)
        {
            iCounter ++;
        }
        
    }
    return iCounter;

}

int main()
{
    int iSize = 0;
    int *ptr = NULL;
    int iCnt = 0;
    int iRet = 0;

    // Step1 = Accept the number of element from user
    printf("Enter the number of element :");
    scanf("%d", &iSize);

    // Sept2 = Allocate memory dynamically
    ptr = (int *)malloc (iSize * sizeof(int));

    // Step3 = Accept the value from user
    printf("Enter the element :");
    for(iCnt = 0; iCnt < iSize; iCnt++)
    {
        scanf("%d", &ptr[iCnt]);
    }

    printf("Element of array are :");

    for(iCnt = 0; iCnt < iSize; iCnt++)
    {
        printf("%d\n", ptr[iCnt]);
    }

    // Step4 = Pass the array to the function
    iRet = EvenCountDispay(ptr, iSize); //Demo(400, 4)

    printf("Even number count is : %d\n", iRet);

    // Step6 = Deallocate the memory of array
    free(ptr);

    return 0;
}