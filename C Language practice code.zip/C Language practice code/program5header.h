#include<stdio.h>

//Function prototype

unsigned int Addition(unsigned int, unsigned int);