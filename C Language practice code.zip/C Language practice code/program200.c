/////////////////////////////////////////////////////////////
//
// Function name : stricmpX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 23/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the String revers the string
//
/////////////////////////////////////////////////////////////

/*
    str1  sanket
    str2  teknas
*/

#include<stdio.h>
#include<stdbool.h>

void strrevX(char *str)
{
    char *start = NULL;
    char *end = NULL;
    char temp = '\0';


    start = str;
    end = str;

    while(*end != 0)
    {
        end++;
    }
    end--;

    while(start < end)
    {
        temp = *start;
        *start = *end;
        *end = temp;

        start++;
        end--;
    }
}

int main()
{
    char Arr[20] ;

    printf("Revers string is : \n");
    scanf("%[^'\n']s",Arr);

    strrevX(Arr);

    printf("Revers string is : %s\n",Arr);
    
    return 0;
}
