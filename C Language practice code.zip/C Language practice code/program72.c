/////////////////////////////////////////////////////////////
//
// Function name : main
// input         : integer
// Output        : integer
// Discption     : use of malloc
// Auther        : Tahakik Sanket Rajendra
// Date          : 10/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Array
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdlib.h>

int main()
{
    int Arr[5];

    printf("Enter the element :");
    scanf("%d", &Arr[0]);
    scanf("%d", &Arr[1]);
    scanf("%d", &Arr[2]);
    scanf("%d", &Arr[3]);
    scanf("%d", &Arr[4]);

    printf("Element of array are :");
    printf("%d\n", Arr[0]);
    printf("%d\n", Arr[1]);
    printf("%d\n", Arr[2]);
    printf("%d\n", Arr[3]);
    printf("%d\n", Arr[4]);

    return 0;
}