/////////////////////////////////////////////////////////////
//
// Function name : MaximumDigit
// input         : integer
// Output        : integer
// Discption     : Accept the number and return biggest number in digits
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the number and return biggest number in digits
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

int MaximumDigit(int iNo)
{
    int iDigits = 0;
    int iBig = 0;
    
    if(iNo < 0)
    {
        iNo = -iNo ;
    }

    while (iNo != 0)
    {
        iDigits = iNo % 10;
        if(iDigits > iBig)
        {
            iBig = iDigits;
        }

        iNo = iNo / 10;
    }
    return iBig;
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number \n");
    scanf("%d", &iValue);
  

    iRet = MaximumDigit(iValue);
    
    printf("%d", iRet);

    return 0;
}