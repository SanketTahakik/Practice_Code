/////////////////////////////////////////////////////////////
//
// Function name : CheckPallidrome
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 23/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the String and check whether string are palidroom without flag
//
/////////////////////////////////////////////////////////////

/*
    str1  nayan
    str2  nayan

    str1  najan
    str2  najan
*/

#include<stdio.h>
#include<stdbool.h>

bool CheckPallidrome(char *str)
{
    char *start = NULL;
    char *end = NULL;

    start = str;
    end = str;

    while(*end != '\0')
    {
        end++;
    }
    end--;

    while(start < end)
    {
        if(*start != *end)
        {
            break;
        }
        start++;
        end--;
    }
    if(start < end)
    {
        return false;
    }
    else
    {
        return true;
    }
}

int main()
{
    char Arr[20] ;
    bool bRet = false;

    printf("Revers string is : \n");
    scanf("%[^'\n']s",Arr);

    bRet = CheckPallidrome(Arr);

    if(bRet == true)
    {
        printf("String is pallindrom\n");
    }
    else
    {
        printf("String is not a pallindrom\n");
    }
    
    return 0;
}
