/////////////////////////////////////////////////////////////
//
// Function name : FristOccurance
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String and character form user and return Frist occurances 
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#define ERR_NOTFOUND -1

int FristOccurance(char *str, char cValue)
{
    int iCnt = 1;
    int iPos = ERR_NOTFOUND;

    while(*str != 0)
    {
        if(*str == cValue)
        {
            iPos= iCnt;
            break;
        }
        str++;
        iCnt++;
    }
    return iPos;
}

int main()
{
    char Arr[20] ;
    char ch = '\0';
    int iRet = 0;

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    printf("Enter the String : \n");
    scanf(" %c",&ch);

    iRet = FristOccurance(Arr, ch);

    if(iRet == ERR_NOTFOUND)
    {
        printf("There is no such character");
    }
    else
    {
        printf("Frist Occurance of that character is at : %d",iRet);
    }
    return 0;
}

/*
Enter the String : 
Sanket
Enter the String : 
k
Frist Occurance of that character is at : 4
*/