/////////////////////////////////////////////////////////////
//
// Function name : strcpyToogleX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the String and copied to another string only Capital letter 
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

void strcpyToogleX(char *src, char *dest)
{
    while(*src != '\0')
    {
        if(*src >= 'A' && *src <= 'Z')
        {
            *dest = *src + 32;
            dest++;
        }
        else if(*src >= 'a' && *src <= 'z')
        {
            *dest = *src - 32;
            dest++;
        }
        else
        {
            *dest = *src;
        }
        src++;
    }
    *dest = '\0';
}

int main()
{
    char Arr[20] ;
    char Brr[20];

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    strcpyToogleX(Arr,Brr);

    printf("String after copy is %s\n",Brr);
    
    return 0;
}
