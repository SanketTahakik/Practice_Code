/////////////////////////////////////////////////////////////
//
// Function name : Countz
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String for user and count the user input char
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>

int Countz(char *str, char cValue)
{
    int iCount = 0;

    while (*str != '\0')
    {
        if(*str == cValue)
        {
            iCount++;
        }
        str++;
    }
    return iCount;
    
}

int main()
{
    char Arr[20];
    char ch = '\0';
    int iRet = 0;

    printf("Enter String :\n");
    scanf("%[^'\n']s", Arr); 

    printf("Enter the character :\n");
    scanf(" %c", &ch);

    iRet = Countz(Arr, ch);

    printf("Number of character are : %d",iRet);

   return 0;
}
