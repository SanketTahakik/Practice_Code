/////////////////////////////////////////////////////////////
//
// Function name : Addition
// input         : Create new header file
// Output        : unsigned integer
// Discption     : use of header file
// Auther        : Tahakik Sanket Rajendra
// Date          : 19/04/2023
//
/////////////////////////////////////////////////////////////

#include"program5header.h"

//////////////////////////////////////////////////////////////
// Entry point function
//////////////////////////////////////////////////////////////

int main()
{
    unsigned No1 = 0, No2 = 0, Ans =0;

    printf ("Enter the frist value : ");
    scanf ("%d", &No1);

    printf("Enter the secont value : ");
    scanf ("%d", &No2);
    
    Ans = Addition(No1, No2);

    printf("Addition is : %d \n", Ans);

    return 0;    
}