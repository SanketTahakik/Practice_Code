/////////////////////////////////////////////////////////////
//
// Function name : main
// input         : integer
// Output        : integer
// Discption     : use of malloc
// Auther        : Tahakik Sanket Rajendra
// Date          : 10/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Array using for loop
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdlib.h>

int main()
{
    int Arr[5];

    printf("Enter the element :");
    
    for(int iCnt = 0; iCnt<5; iCnt++)
    {
        scanf("%d", &Arr[iCnt]);
    }

    printf("Element of array are :");
    
    for(int iCnt = 0; iCnt<5; iCnt++)
    {
        printf("%d",Arr[iCnt]);
    }

    return 0;
}