/////////////////////////////////////////////////////////////
//
// Function name : Display
// input         : Integer
// Output        : Integer
// Discption     : Printing 1 to 5 using for loop in function
// Auther        : Tahakik Sanket Rajendra
// Date          : 26/04/2023 
//
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display 1 to 5 on screen using function
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

void Display()
{
    int iCnt = 0;
    for(iCnt = 1; iCnt <=5; iCnt++)
    {
        printf("%d \n", iCnt);
    }
}
int main()
{
    Display();

    return 0;
}