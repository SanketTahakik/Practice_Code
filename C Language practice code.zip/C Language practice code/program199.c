/////////////////////////////////////////////////////////////
//
// Function name : stricmpX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 23/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the two String and compare with k sencetive
//
/////////////////////////////////////////////////////////////

/*
    str1  DeMo
    str2  dEmO
*/

#include<stdio.h>
#include<stdbool.h>

bool stricmpX(char *str1, char *str2)
{
    while ((*str1 != '\0') && (*str2 != '\0'))
    {
        if(*str1 != *str2) // letter are differnt  
        {
            if((*str1 >= 'a') && (*str1 <= 'z')) // frist letter is small
            {
                if(*str1 != (*str2 + 32))
                {
                    break;
                }
            }
            else if((*str1 >= 'A') && (*str1 <= 'Z')) // frist letter is capital
            {
                if(*str1 != (*str2 - 32))
                {
                    break;
                }
            }
            else  // special symbol and digits
            {
                break; 
            }
        }

        str1++;
        str2++;
    }
    if((*str1 == '\0') && (*str2 == '\0'))
    {
        return true;
    }
    else
    {
        return false;
    }
    
}

int main()
{
    char Arr[20] ;
    char Brr[20] ;
    bool bRet = true;

    printf("Enter the Frist String : \n");
    scanf("%[^'\n']s",Arr);

    printf("Enter the Second String : \n");
    scanf(" %[^'\n']s",Brr);

    bRet = stricmpX(Arr, Brr);
    //             100, 200

    if(bRet == true)
    {
        printf("Both string are identical \n");
    }
    else
    {
        printf("Both string are diffrent \n");
    }

    return 0;
}
