/////////////////////////////////////////////////////////////
//
// Function name : CheckDigits
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String for user and calculet vowels eg a e i o u
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/
// a e i o u
// A E I O U

#include<stdio.h>

int CountVowels(char *str)
{
    int iCount = 0;

    while (*str != '\0')
    {
        if((*str == 'a')|| (*str == 'e') || (*str == 'i')|| (*str == 'o') || (*str == 'u') || (*str == 'A')|| (*str == 'E')|| (*str == 'I')|| (*str == 'O')|| (*str == 'U'))
        {
            iCount++;
        }
        str++;
    }
    return iCount;
    
}

int main()
{
    char Arr[20];
    int iRet = 0;

    printf("Enter String :\n");
    scanf("%[^'\n']s", Arr); 

    iRet = CountVowels(Arr);

    printf("Length of Digits are : %d",iRet);

   return 0;
}
