/*
    Step to create the application

    Step 1 : Understand the problem statement
    Step 2 : Write the algorithm
    Step 3 : Deside programmin language
    Step 4 : Write a program
    Step 5 : Test the wrtten program
*/
/*
    Algorithm 

    START
        Accept Frist Number as No1
        Accept Scecond number as No 2
        Create one variable as ANS
        Perform Addition of No1 and No2
        Store the Addition in ANS

*/

#include<stdio.h>
int main()
{
    int No1 = 0;
    int No2 = 0;
    int Ans = 0;
     
    printf("Enter the frist number : \n");
    scanf("%d",&No1);
    
     printf("Enter the secont number : \n");
    scanf("%d",&No2);
    
    Ans = No1 + No2;
     
    printf("Addition is : %d \n", Ans);

    return 0;
}
