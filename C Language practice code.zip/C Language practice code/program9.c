/////////////////////////////////////////////////////////////
//
// Function name : Main
// input         : Integer
// Output        : Integer
// Discption     : Print Jay Ganesh in 5 times
// Auther        : Tahakik Sanket Rajendra
// Date          : 26/04/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display Jay Ganesh in 5 time on screen
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int main()
{

    printf("Jay Ganesh....\n");  
    printf("Jay Ganesh....\n");  
    printf("Jay Ganesh....\n");  
    printf("Jay Ganesh....\n");  
    printf("Jay Ganesh....\n");  

    return 0;
}