/////////////////////////////////////////////////////////////
//
// Function name : CountDigits
// input         : integer
// Output        : integer
// Discption     : problem on Digits
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  print given number count.
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int CountDigits(int iNo)
{
    int iDigits = 0;
    int iCnt = 0;

    while (iNo != 0)
    {
        iDigits = iNo % 10;
        iCnt++;
        iNo = iNo / 10;
    }
    return iCnt;
}
int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number : ");
    scanf ("%d", &iValue);

    iRet = CountDigits(iValue);
    printf("number in digits are : %d",iRet);

    return 0 ;
}

/*

iNo = 761;

iDigit = iNo % 10 ;         1
iNo = iNo / 10;             76

iDigit = iNo % 10 ;         6
iNo = iNo / 10;             7

iDigit = iNo % 10 ;         7
iNo = iNo / 10;             0


*/