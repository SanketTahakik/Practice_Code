/////////////////////////////////////////////////////////////
//
// Function name : strcmpX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 23/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the two String and combine two string convet into for loop with body
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdbool.h>

bool strcmpX(char *str1, char *str2)
{
    for( ;((*str1 != '\0') && (*str2 != '\0') && (*str1 == *str2)); str1++,str2++);
    // ; is important


    return (((*str1 == '\0') && (*str2 == '\0')));
      
}

int main()
{
    char Arr[20] ;
    char Brr[20] ;
    bool bRet = true;

    printf("Enter the Frist String : \n");
    scanf("%[^'\n']s",Arr);

    printf("Enter the Second String : \n");
    scanf(" %[^'\n']s",Brr);

    bRet = strcmpX(Arr, Brr);
    //             100, 200

    if(bRet == true)
    {
        printf("Both string are identical \n");
    }
    else
    {
        printf("Both string are diffrent \n");
    }

    return 0;
}
