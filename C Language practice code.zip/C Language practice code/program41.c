/////////////////////////////////////////////////////////////
//
// Function name : Factorial
// input         : integer
// Output        : integer
// Discption     : Print the backworld number Multipication eg. input 3 = 3 * 2 * 1 = 6 output
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Print the backworld number Multipication using typedef
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

typedef unsigned long int ULONG;

ULONG Factorial(int iNo)
{
    int iCnt = 0;

    ULONG iResult = 1;
    for (iCnt = 1; iCnt <= iNo; iCnt++)
    {
        iResult = iResult * iCnt;
    }
    return iResult;
}

int main()
{
    int iValue = 0;
    ULONG iRet = 0;

    printf("Enter the number :");
    scanf("%d", &iValue);

    iRet = Factorial(iValue);

    printf("Result is : %d ", iRet);

    return 0;   
}