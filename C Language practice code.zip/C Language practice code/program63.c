/////////////////////////////////////////////////////////////
//
// Function name : ReverseNumber
// input         : integer
// Output        : integer
// Discption     : Accept the number and reverse number
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Accept the number and reverse number
//
/////////////////////////////////////////////////////////////

/*
    iReverse = (iReverse *10) + iDigits;
*/

#include<stdio.h>

int ReverseNumber(int iNo)
{
    int iDigits = 0;
    int iReverse = 0;

    while (iNo != 0)
    {
        iDigits = iNo % 10;
        iReverse = (iReverse * 10) + iDigits;
        iNo = iNo / 10;
    }
    return iReverse;
    
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number \n");
    scanf("%d", &iValue);
  

    iRet = ReverseNumber(iValue);
    printf("%d", iRet);

    return 0;
}