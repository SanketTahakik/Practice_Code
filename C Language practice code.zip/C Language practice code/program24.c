/////////////////////////////////////////////////////////////
//
// Function name : DisplayFactor
// input         : integer
// Output        : integer
// Discption     : Print Factorial but half number of itteration
// Auther        : Tahakik Sanket Rajendra
// Date          : 02/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Print the factorials
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

void DisplayFactor(int iNo)
{
    for(int iCnt = 1; iCnt <= (iNo/2); iCnt++)
    {
        if((iNo % iCnt) == 0)
        {
            printf("%d\n", iCnt);
        }
    }
}

int main()
{
    int iValue = 0;

    printf("Enter the number : \n");
    scanf("%d", &iValue);

    DisplayFactor(iValue);
    
    return 0;
}