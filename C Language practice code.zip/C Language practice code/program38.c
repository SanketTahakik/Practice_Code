/////////////////////////////////////////////////////////////
//
// Function name : DisplayB
// input         : integer
// Output        : integer
// Discption     : Print the backworld number 5 4 3 2 1
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Print the backworld number
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

void DisplayB(int iNo)
{
    for(int iCnt = iNo; iCnt >= 1; iCnt--)
    {
        printf("%d \t",iCnt);
    }
}

int main()
{
    int iValue = 0;
    printf("Enter the number :");
    scanf("%d", &iValue);

    DisplayB(iValue);

    return 0;   
}