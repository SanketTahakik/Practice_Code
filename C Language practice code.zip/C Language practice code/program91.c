/////////////////////////////////////////////////////////////
//
// Function name : SearchFristOccurance
// input         : integer
// Output        : integer
// Discption     : Find the Maximum number in array.
// Auther        : Tahakik Sanket Rajendra
// Date          : 14/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Find the Value are present and print Array index
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdbool.h>
#define ERR_NOTFOUND -1

int SearchFristOccurance(int Arr[], int iLength, int iNo)
{
    int iCnt = 0;
    for (iCnt = 0; iCnt < iLength; iCnt++)
    {
        if(Arr[iCnt] == iNo)
        {
            break;
        }
    }
    
    if(iCnt == iLength)
    {
        return ERR_NOTFOUND;
    }
    else
    {
        return iCnt;
    }
    
}


int main()
{
    int iSize = 0;
    int *ptr = NULL;
    int iValue = 0;
    int iRet = 0;

    printf("Enter the size : ");
    scanf("%d",&iSize);

    printf("Enter the Value : ");
    scanf("%d",&iValue);

    ptr = (int *)malloc(iSize * sizeof(int));

    printf("Enter the value :\n");
    for (int iCnt = 0; iCnt < iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    printf("Your Enter the value :\n");
    for (int iCnt = 0; iCnt < iSize; iCnt++)
    {
        printf("%d\n",ptr[iCnt]);
    }

    iRet = SearchFristOccurance(ptr , iSize, iValue);

    if(iRet == ERR_NOTFOUND)
    {
        printf("There is no element present ");
    }
    else
    {
        printf("%d",iRet);
    } 
    
    free(ptr);

    return 0;
}