/////////////////////////////////////////////////////////////
//
// Function name : SumDigits
// input         : integer
// Output        : integer
// Discption     : print given number count, use of While loop
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  print given number sum
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int SumDigits(int iNo)
{
    int iSum = 0;
    int iDigits = 0;

    while (iNo != 0)
    {
        iDigits = iNo % 10;
        iSum = iSum + iDigits;
        iNo = iNo / 10;
    }
    return iSum;
}
int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number : ");
    scanf ("%d", &iValue);

    iRet = SumDigits(iValue);
    printf("number in digits are : %d",iRet);

    return 0 ;
}