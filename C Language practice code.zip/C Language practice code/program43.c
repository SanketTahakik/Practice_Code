/////////////////////////////////////////////////////////////
//
// Function name : DispayF
// input         : integer
// Output        : integer
// Discption     : Display number in forworld direction using of while loop
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display number in forworld direction using of while loop
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

void DisplayF(int iNo)
{
    int iCnt = 0;

    iCnt = 1;
    while (iCnt <= iNo)
    {
        printf("%d \t", iCnt);
        iCnt++;
    }
    
}

int main()
{
    int iValue = 0;
    printf("Enter the number :");
    scanf("%d", &iValue);

    DisplayF(iValue);

    return 0;   
}