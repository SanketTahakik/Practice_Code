///////////////////////////////////////////////////////////////
// 
// Function name : Check Even or Odd
// Input         : Interger
// Output        : Boolen
// Description   : Check number is Even or Odd
// Auther        : Sanket Rajendra Tahakik
// Date          : 25/04/2023
//
////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
//
// Write a program which checks whether number is enen or odd
//
//////////////////////////////////////////////////////////////

#include<stdio.h>   // For printf or scanf
#include<stdbool.h> // For bool data type

bool CheckEvenOdd(int iNo)
{    
    if((iNo % 2) == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
        
}

///////////////////////////////////////////////////////////////
// Entry point
///////////////////////////////////////////////////////////////

int main()
{
    int iValue = 0;    // variable ti accept input
    bool bRet = false; // variable to accept return value

    printf("Please enter number to check it is even or odd : \n");
    scanf("%d" ,&iValue);

    bRet = CheckEvenOdd(iValue);  // Function call

    if (bRet == true)
    {
        printf("%d is Even number \n", iValue);
    }
    else
    {
        printf("%d is odd number \n", iValue);
    }
    
    return 0;
}