/////////////////////////////////////////////////////////////
//
// Function name : Check pass or fail
// input         : integer
// Output        : integer
// Discption     : Use of if else loop for check pass or fail
// Auther        : Tahakik sanket Rajendra
// Date          : 25/04/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Write a program which accept the mark and display the class accordingly
//
/////////////////////////////////////////////////////////////


// 0 to 35         fail
// 35 to 50        pass
// 50 to 75        2nd class
// 75 to 100       1st class

#include <stdio.h>

void DisplayClass(float fMarks)
{
    if ((fMarks < 0.0f) || (fMarks > 100.0f))
    {
        printf("Invalid syntac");
    }

    if ((fMarks >= 0.0) && (fMarks <= 34.00f))
    {
        printf("fail");
    }

    else if ((fMarks >= 35) && (fMarks <= 50))
    {
        printf("pass");
    }

    else if ((fMarks >= 50) && (fMarks <= 75))
    {
        printf("3nd class");
    }

    else if ((fMarks >= 75) && (fMarks <= 100))
    {
        printf("1st class");
    }
}
int main()
{
    float fValue = 0.0f;

    printf("Enter your percentage :");
    scanf("%f", &fValue);

    DisplayClass(fValue);
}