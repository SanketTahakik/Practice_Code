/////////////////////////////////////////////////////////////
//
// Function name : Factorial
// input         : integer
// Output        : integer
// Discption     : Display Factorial multipication using of while loop
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display Factorial multipication
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int Factorial(int iNo)
{
    int iCnt = 0;
    int iResult = 1;

    iCnt = 1;
    while (iCnt <= iNo)
    {
        iResult = iResult * iCnt;
        iCnt ++;
    }
    
    return iResult;
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number :");
    scanf("%d", &iValue);

    iRet = Factorial(iValue);

    printf("Result is : %d ", iRet);

    return 0;   
}