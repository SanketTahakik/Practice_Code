/////////////////////////////////////////////////////////////
//
// Function name : EditString
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Find and replace Capital leter to * Small with $
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

void EditString(char *str)
{
    while(*str != '\0')
    {
        if(*str >= 'A' && *str <= 'Z'  )
        {
            *str = '*';
        }
        else if(*str >= 'a' && *str <= 'z')
        {
            *str = '$';
        }
        str++;
    }
}

int main()
{
    char Arr[20] ;

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    EditString(Arr);

    printf("String after editing is %s\n",Arr);
    
    return 0;
}
