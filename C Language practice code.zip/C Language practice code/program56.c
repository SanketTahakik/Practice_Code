/////////////////////////////////////////////////////////////
//
// Function name : CheckDigits
// input         : integer
// Output        : integer
// Discption     : Accept the number and check in number 8 is present or not use of flag
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Accept the number and check in number 8 is present or not
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdbool.h>

bool CheckDigits(int iNo)
{
    int iDigit = 0;
    bool bFlag = false;

    while(iNo != 0)
    {
        iDigit = iNo % 10;

        if(iDigit == 8)
        {
            bFlag = true;
            break;
        }
        iNo = iNo / 10;
    } 
    return bFlag;
}

int main()
{
    int iValue = 0;
    bool iRet = true;
    printf("Enter the number \n");
    scanf("%d", &iValue);

    iRet = CheckDigits(iValue);

    if(iRet == true)
    {
        printf("8 is present ");
    }
    else{
        printf("8 is not present ");
    }
    return 0;
}