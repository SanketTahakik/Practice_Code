/////////////////////////////////////////////////////////////
//
// Function name : strwrX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Find and replace Small with Capital
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

void strwrX(char *str)
{
    while(*str != '\0')
    {
        if(*str >= 'A' && *str <= 'Z'  )
        {
            *str = *str +32;
        }
        str++;
    }
}

int main()
{
    char Arr[20] ;

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    strwrX(Arr);

    printf("String after editing is %s\n",Arr);
    
    return 0;
}
