/////////////////////////////////////////////////////////////
//
// Function name : Display
// input         : integer
// Output        : Integer
// Discption     : Use of Updator
// Auther        : Tahakik Sanket Rajendra
// Date          : 26/04/2023
//
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display 1 to 5 on screen
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int main()
{
    printf("1\n");
    printf("2\n");
    printf("3\n");
    printf("4\n");
    printf("5\n");

    return 0;
}