/////////////////////////////////////////////////////////////
//
// Function name : DisplayDigits
// input         : integer
// Output        : integer
// Discption     : Print digits
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Print digits in for loop variation
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

void DisplayDigits(int iNo)
{
    int iDigit = 0;
    for(  ;iNo != 0; iNo = iNo / 10)
    {
        iDigit = iNo % 10;
        printf("%d", iDigit);
    }
}

int main()
{
    int iValue = 0;

    printf("Enter the number \n");
    scanf("%d", &iValue);

    DisplayDigits(iValue);

    return 0;
}