/////////////////////////////////////////////////////////////
//
// Function name : CountOddDigits
// input         : integer
// Output        : integer
// Discption     : Accept the number form user and check count of Odd number
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the number form user and check count of Odd number
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

int CountOddDigits(int iNo)
{
    int iDigit = 0;
    int iSum = 0;

    while(iNo != 0)
    {
        iDigit = iNo % 10;

        if(iDigit % 2 != 0)
        {
           iSum = iSum + 1;            
        }
        iNo = iNo / 10;
    } 
    return iSum;

}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number \n");
    scanf("%d", &iValue);
  

    iRet = CountOddDigits(iValue);
    printf("%d", iRet);

    return 0;
}