/////////////////////////////////////////////////////////////
//
// Function name : CheckCapital
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept character for user and check to character is Small or not
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>
#include<stdbool.h>

bool CheckSmall(char cValue)
{
    if((cValue >= 'a') && (cValue <= 'z'))
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
   char ch = '\0';
   bool bRet = false;

   printf("Enter the character :\n");
   scanf("%c",&ch);

   bRet = CheckSmall(ch);

    if(bRet == true)
    {
        printf("%c is a Small letter \n",ch);
    }
    else
    {
        printf("%c is a not Small letter \n",ch);
    }

   return 0;

}
