/////////////////////////////////////////////////////////////
//
// Function name : DisplayDigits
// input         : integer
// Output        : integer
// Discption     : Print the digits for given number in for loop
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Print the digits for given number in for loop
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

void DisplayDigits(int iNo)
{
    int iDigit = 0;
    for(  ;iNo != 0; )
    {
        iDigit = iNo % 10;
        printf("%d", iDigit);
        iNo = iNo / 10;
    }
}

int main()
{
    int iValue = 0;

    printf("Enter the number \n");
    scanf("%d", &iValue);

    DisplayDigits(iValue);

    return 0;
}