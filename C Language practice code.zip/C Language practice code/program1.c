#include<stdio.h>

int main()
{
    printf("hello Sanket");

    return 0;

}
//////////////////////////////////////////////////////////////////////

// command to compile the code
// gcc program1.c
// ./a.exe      (windows)
// ./a.out      (Linux)