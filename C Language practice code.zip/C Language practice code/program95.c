/////////////////////////////////////////////////////////////
//
// Function name : Display
// input         : integer
// Output        : integer
// Discption     : Pattern printing
// Auther        : Tahakik Sanket Rajendra
// Date          : 15/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Pattern printing
//
/////////////////////////////////////////////////////////////

/*
    input = 4
    output = # # # #
*/

#include<stdio.h>

void Display(int iNo)
{
    for (int iCnt = 0; iCnt < iNo; iCnt++)
    {
        printf("*\t");
    }
    printf("\n");
}

int main()
{
    int iFrequency = 0;
    printf("Enter the frequency of symbol : \n");
    scanf("%d",&iFrequency);

    Display(iFrequency);
 
    return 0;
}