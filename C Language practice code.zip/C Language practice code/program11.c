/////////////////////////////////////////////////////////////
//
// Function name : Display
// input         : integer
// Output        : integer
// Discption     : Print Jay Ganesh use of for loop in function
// Auther        : Tahakik Sanket Rajendra
// Date          : 26/04/2023
//
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display Jay Ganesh in 5 time on screen help of function
//
/////////////////////////////////////////////////////////////

#include <stdio.h>

void Display()
{
    int iCnt = 0;
    for (iCnt = 1; iCnt <= 5; iCnt++)
    {
        printf("Jay Ganesh....\n");
    }
}

int main()
{
    Display();

    return 0;
}