/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : Integer
// Discption     : Use of for loop to print 1 to 5
// Auther        : Tahakik Sanket Rajendra
// Date          : 26/04/2023
//
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display 1 to 5 on screen
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int main()
{
    int iCnt = 0;
    for(iCnt = 1; iCnt <=5; iCnt++)
    {
        printf("%d \n", iCnt);
    }
    return 0;
}