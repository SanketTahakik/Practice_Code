/////////////////////////////////////////////////////////////
//
// Function name : CountDigits
// input         : integer
// Output        : integer
// Discption     : Accept the number and check the number 8 how many present in number
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Accept the number and check the number 8 how many present in number
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

int CountDigits(int iNo)
{
    int iDigit = 0;
    int iSum = 0;
    while(iNo != 0)
    {
        iDigit = iNo % 10;

        if(iDigit == 8)
        {
           iSum = iSum + 1;            
        }
        iNo = iNo / 10;
    } 
    return iSum;

}

int main()
{
    int iValue = 0;
    int iRet = 0;
    printf("Enter the number \n");
    scanf("%d", &iValue);

    iRet = CountDigits(iValue);
    printf("%d", iRet);

    return 0;
}