/////////////////////////////////////////////////////////////
//
// Function name : strNcatX
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 22/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the String and copied to another string but given input only copied
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

// 1 : Travel till end of dest 
// 2 : copy the data from src to dest
// 3 : Write '\0' at the end of dest

void strNcpyX(char *src, char *dest , int iLength)
{
    while((*src != '\0') && (iLength != 0))
        {
            *dest = *src;
            src++;
            dest++;
            iLength--;
        }

        *dest = '\0';   
}

int main()
{
    char Arr[20] ;
    char Brr[20] = "Demo";
    int iNo = 0;

    printf("Enter the String : \n");
    scanf("%[^'\n']s",Arr);

    printf("Enter the number of letter that you want to copy : \n");
    scanf("%d",iNo);

    strNcpyX(Arr,Brr, iNo);

    printf("String after copy is %s\n",Brr);
    
    return 0;
}
