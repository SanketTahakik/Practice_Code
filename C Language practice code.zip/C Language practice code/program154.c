/////////////////////////////////////////////////////////////
//
// Function name : CheckCapital
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept character for user and check to character is capital or not
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>
#include<stdbool.h>

bool CheckCapital(char cValue)
{
    if((cValue >= 'A') && (cValue <= 'Z'))
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
   char ch = '\0';
   bool bRet = false;

   printf("Enter the character :\n");
   scanf("%c",&ch);

   bRet = CheckCapital(ch);

    if(bRet == true)
    {
        printf("%c is a capital letter \n",ch);
    }
    else
    {
        printf("%c is a not capital letter \n",ch);
    }

   return 0;

}
