/////////////////////////////////////////////////////////////
//
// Function name : SmallDigit
// input         : integer
// Output        : integer
// Discption     : Accept the number and return smallest number in digits
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :   Accept the number and return smallest number in digits
//
/////////////////////////////////////////////////////////////


#include<stdio.h>

int SmallDigit(int iNo)
{
    int iDigits = 0;
    int iSmall = 9;
    
    if(iNo < 0)
    {
        iNo = -iNo ;
    }

    while (iNo != 0)
    {
        iDigits = iNo % 10;
        if(iDigits < iSmall)
        {
            iSmall = iDigits;
        }

        iNo = iNo / 10;
    }
    return iSmall;
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number \n");
    scanf("%d", &iValue);
  

    iRet = SmallDigit(iValue);
    
    printf("%d", iRet);

    return 0;
}