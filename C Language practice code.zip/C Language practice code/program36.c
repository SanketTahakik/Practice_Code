/////////////////////////////////////////////////////////////
//
// Function name : CalculetPower
// input         : integer
// Output        : integer
// Discption     : Calculet the x^y , x is 2 and y is 3 is equal to 8, use of typedef. typedef unsigned long int ULONG;
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Calculet the x^y 
//
/////////////////////////////////////////////////////////////

/*
    x = 2;
    y = 3;
    2 * 2 * 2 = 8;
*/

#include<stdio.h>
#include<stdbool.h>

typedef unsigned long int ULONG;

ULONG CalulatePower(int iNo1, int iNo2)
{
    ULONG iResult = 1;

    if(iNo1 < 0 || iNo2 < 0)
    {
        return 0;
    }

    for(int iCnt = 1; iCnt <= iNo2; iCnt++)
    {
        iResult = iResult * iNo1;
    }
    return iResult;
}

int main()
{
    int iValue1 = 0, iValue2 = 0;
    ULONG iRet = 0;

    printf("Enter the base : \n");
    scanf("%d", &iValue1);
    printf("Enter the power : \n");
    scanf("%d", &iValue2);

    iRet = CalulatePower(iValue1,iValue2);

    printf("reuslt is : %d\n", iRet);
    return 0;
}