/////////////////////////////////////////////////////////////
//
// Function name : Addition
// input : unsigned integer, unsigned integer
// Output :  unsigned integer
// Discption : Addition of two number
// Auther : Tahakik sanket Rajendra
// Date : 18/04/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Write a program which performs addition of two number
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

// Addition
unsigned int Addition(unsigned iValue1, unsigned iValue2)
{
    unsigned int iResult = 0;
    iResult = iValue1 + iValue2;
    return iResult;
}

//////////////////////////////////////////////////////////////
// Entry point function
//////////////////////////////////////////////////////////////

int main()
{
    unsigned No1 = 0, No2 = 0, Ans =0;

    printf ("Enter the frist value : ");
    scanf ("%d", &No1);

    printf("Enter the secont value : ");
    scanf ("%d", &No2);
    
    Ans = Addition(No1, No2);

    printf("Addition is : %d \n", Ans);

    return 0;    
}