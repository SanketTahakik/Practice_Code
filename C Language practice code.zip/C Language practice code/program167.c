/////////////////////////////////////////////////////////////
//
// Function name : Countz
// input         : integer
// Output        : integer
// Discption     : Problem on String
// Auther        : Tahakik Sanket Rajendra
// Date          : 21/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String for user and count z
//
/////////////////////////////////////////////////////////////

/*
    input :
    Output :
*/

#include<stdio.h>

int Countz(char *str)
{
    int iCount = 0;

    while (*str != '\0')
    {
        if(*str == 'z')
        {
            iCount++;
        }
        str++;
    }
    return iCount;
    
}

int main()
{
    char Arr[20];
    int iRet = 0;

    printf("Enter String :\n");
    scanf("%[^'\n']s", Arr); 

    iRet = Countz(Arr);

    printf("Number of z are : %d",iRet);

   return 0;
}
