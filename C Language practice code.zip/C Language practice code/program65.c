/////////////////////////////////////////////////////////////
//
// Function name : CheckPallindrome
// input         : integer
// Output        : integer
// Discption     : Accept the number and reverse number
// Auther        : Tahakik Sanket Rajendra
// Date          : 07/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the number and check pallindrome
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdbool.h>

bool CheckPallindrome(int iNo)
{
    int iDigits = 0;
    int iReverse = 0;
    int itemp = iNo;

    while (iNo != 0)
    {
        iDigits = iNo % 10;
        iReverse = (iReverse *10) + iDigits;
        iNo = iNo / 10;
    }
    
    if(iReverse == itemp)
    {
        return true;
    }
    else
    {
        return false;
    } 
}

int main()
{
    int iValue = 0;
    bool bRet = 0;

    printf("Enter the number \n");
    scanf("%d", &iValue);
  

    bRet = CheckPallindrome(iValue);
    
    if(bRet == true)
    {
        printf("Number is pallindrome number ");
    }
    else
    {
        printf("Number is not pallindrome number ");
    }

    return 0;
}