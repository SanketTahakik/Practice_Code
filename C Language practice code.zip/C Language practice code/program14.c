/////////////////////////////////////////////////////////////
//
// Function name : Display
// input         : integer
// Output        : String
// Discption     : Use of Updator
// Auther        : Tahakik Sanket Rajendra
// Date          : 26/04/2023
//
/////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
// Problem Statement :  Display Jay Ganesh in 5 time on screen
//
/////////////////////////////////////////////////////////////

#include <stdio.h>

void Display(int iNo)
{
    int iCnt = 0;
///////////////////////////////////////////////////////////////
//
// Updator
//
///////////////////////////////////////////////////////////////
    if(iNo < 0) 
    {
        iNo = -iNo;
    }


    for (iCnt = 1; iCnt <= iNo; iCnt++)
    {
        printf("Jay Ganesh....\n");
    }
}

int main()
{
    int iValue = 0;

    printf("Enter the number of printing jay ganesh :");
    scanf("%d", &iValue);

    Display(iValue);

    return 0;
}