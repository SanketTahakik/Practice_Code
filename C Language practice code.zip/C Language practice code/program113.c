/////////////////////////////////////////////////////////////
//
// Function name : Display
// input         : integer
// Output        : integer
// Discption     : Pattern printing
// Auther        : Tahakik Sanket Rajendra
// Date          : 15/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Non liniear Pattern printing
//
/////////////////////////////////////////////////////////////

/*
    input :
    Row : 3
    Col : 5

    output :
    * * * * *
    * * * * *
    * * * * *
*/

#include<stdio.h>

void Display(int iRow, int iCol)
{
    int iCnt1 = 0;
    int iCnt2 = 0;
    for(iCnt1 = 1; iCnt1 <= iRow; iCnt1++)
    {
        for(iCnt2 = 1; iCnt2<= iCol; iCnt2++)
        {
            printf("*\t");
        }
        printf("\n");
    }
}

int main()
{
    int iRow = 0;
    int iCol = 0;

    printf("Enter the Rows : \n");
    scanf("%d",&iRow);

    printf("Enter the Columns : \n");
    scanf("%d",&iCol);

    Display(iRow, iCol);
 
    return 0;
}