/////////////////////////////////////////////////////////////
//
// Function name : CheckPrime
// input         : integer
// Output        : boolean
// Discption     : Check prime number With "Flag"
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Check prime number
//
/////////////////////////////////////////////////////////////

/*
    Note - Flag is a zenda. Flag is true then it is open and Flag is false then it is close
*/

/*
    Prime number is that number it only two factor 1 and itself
*/

#include<stdio.h>
#include<stdbool.h>

bool CheckPrime(int iNo)
{
    int iCnt = 0;
    bool bFlag = true;

    for(iCnt = 2; iCnt <= (iNo / 2); iCnt++)
    {
        if((iNo % iCnt) == 0)
        {
            bFlag = false;
            break;
        }
        
    }
    return bFlag;
}

int main()
{
    int iValue = 0;
    bool bRet = false;

    printf("Enter the number : \n");
    scanf("%d", &iValue);

    bRet = CheckPrime(iValue);

    if(bRet == true)
    {
        printf("%d is prime number",iValue);
    }
    else
    {
        printf("%d is not prime number",iValue);
    }
    return 0;
}