/////////////////////////////////////////////////////////////
//
// Function name : SumFactor
// input         : integer
// Output        : integer
// Discption     : Print Addition of factor 
// Auther        : Tahakik Sanket Rajendra
// Date          : 02/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement :  Print the Addition of factorials, use of updator
//
/////////////////////////////////////////////////////////////

#include<stdio.h>

int SumFactor(int iNo)
{
    int iCnt = 0;
    int iSum = 0;


    if(iNo < 0)
    {
        iNo = -iNo;
    }

    for(iCnt = 1; iCnt <= (iNo / 2); iCnt++)
    {
        if((iNo % iCnt) == 0)
        {
            iSum = iSum + iCnt;
        }
    }
    return iSum;
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter the number :\n");
    scanf("%d", &iValue);

    iRet = SumFactor(iValue);

    printf("Summation of factor is : %d\n", iRet);

    return 0;
}