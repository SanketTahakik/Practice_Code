/////////////////////////////////////////////////////////////
//
// Function name : CheckValue
// input         : integer
// Output        : integer
// Discption     : Find the Maximum number in array.
// Auther        : Tahakik Sanket Rajendra
// Date          : 14/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Find the Value are present or not number in array.
//
/////////////////////////////////////////////////////////////

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

bool CheckValue(int Arr[], int iLength, int iNo)
{
    bool bFalg = true;

    for (int iCnt = 0; iCnt < iLength; iCnt++)
    {
        if(Arr[iCnt] == iNo)
        {
            bFalg = false;
            break;
        }
    
    }
    return bFalg;
}


int main()
{
    int iSize = 0;
    int *ptr = NULL;
    int iValue = 0;
    bool bRet = true;

    printf("Enter the size : ");
    scanf("%d",&iSize);

    printf("Enter the Value : ");
    scanf("%d",&iValue);

    ptr = (int *)malloc(iSize * sizeof(int));

    printf("Enter the value :\n");
    for (int iCnt = 0; iCnt < iSize; iCnt++)
    {
        scanf("%d",&ptr[iCnt]);
    }

    printf("Your Enter the value :\n");
    for (int iCnt = 0; iCnt < iSize; iCnt++)
    {
        printf("%d\n",ptr[iCnt]);
    }

    bRet = CheckValue(ptr , iSize, iValue);
    if(bRet == false)
    {
        printf("is present in Array");
    }
    else
    {
        printf("is not present in Array");
    }
    
    free(ptr);

    return 0;
}