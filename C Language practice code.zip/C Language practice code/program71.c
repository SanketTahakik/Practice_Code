/////////////////////////////////////////////////////////////
//
// Function name : main
// input         : integer
// Output        : integer
// Discption     : use of malloc
// Auther        : Tahakik Sanket Rajendra
// Date          : 10/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Use of malloc
//
/////////////////////////////////////////////////////////////


#include<stdio.h>
#include<stdlib.h> //using malloc

int main()
{
    int iSize = 0;
    int *ptr = NULL;

    printf("Enter the number of elements : \n");
    scanf("%d", &iSize);

    ptr = (int*)malloc(iSize * sizeof(int));
    if(ptr == NULL)
    {
        printf("Unable to allocate mamory");
        return -1;
    }

    printf("Memory allocated succesfully");

    return 0;
}