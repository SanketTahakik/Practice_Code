/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Problem on bitwise operator
// Auther        : Tahakik Sanket Rajendra
// Date          : 05/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : convert decimal to hexadecimal
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

void HexaDecimal(int iNo)
{
    int iDigits = 0;

    cout << "Hexadicimal converson if : " << iNo<< " is : " "\n";

    while(iNo != 0)
    {
        iDigits = iNo % 16;

        cout << iDigits;

        iNo = iNo / 16;
    }
    cout << "\n";
}

int main()
{
    int iValue = 0;

    cout << "Enter the nuber :  ";
    cin >> iValue;

    HexaDecimal(iValue);

    return 0;
}