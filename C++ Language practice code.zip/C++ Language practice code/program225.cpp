/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Problem on bitwise operator
// Auther        : Tahakik Sanket Rajendra
// Date          : 05/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : convert digits to binary
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

void DisplayBinary(int iNo)
{
    int iDigits = 0;

    cout << "Binary converson if : " << iNo<< " is : " "\n";

    while(iNo != 0)
    {
        iDigits = iNo % 2;

        cout << iDigits;

        iNo = iNo / 2;
    }
    cout << "\n";
}

int main()
{
    int iValue = 0;

    cout << "Enter the nuber :  ";
    cin >> iValue;

    DisplayBinary(iValue);

    return 0;
}



/*
No1  : 73
No2  : 98

No1     1   0   0   1   0   0   1
No2     1   1   0   0   0   1   0
-----------------------------------------
&       1   0   0   0   0   0   0               (64)

No1     1   0   0   1   0   0   1
No2     1   1   0   0   0   1   0
-----------------------------------------
|       1   1   0   1   0   1   1               (107)

No1     1   0   0   1   0   0   1
No2     1   1   0   0   0   1   0
-----------------------------------------
^       0   1   0   1   0   1   1               (43)


*/


