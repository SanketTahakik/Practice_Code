/////////////////////////////////////////////////////////////
//
// Function name : CheckPallidrome
// input         : integer
// Output        : integer
// Discption     : Use of OOP problems on Digits
// Auther        : Tahakik Sanket Rajendra
// Date          : 27/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept n number form user and Summation this number
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

class Digits
{
    private:
        int iNo;

    public:
        Digits(int X)
        {
            iNo = X;
        }
};

int main()
{
    int iValue = 0;

    cout << "Enter the number :" << "\n";
    cin >> iValue;

    Digits dobj(iValue);

    return 0;
}