/////////////////////////////////////////////////////////////
//
// Function name : CheckPallidrome
// input         : integer
// Output        : integer
// Discption     : Use of OOP
// Auther        : Tahakik Sanket Rajendra
// Date          : 27/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept two number and print maximun number
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

class Number
{
    public:
        int iNo1;
        int iNo2;
        
        void Accept()
        {
            cout << "Enter the frist nubmber" << "\n";
            cin>>iNo1;

            cout << "Enter the seccond nubmber" << "\n";
            cin>>iNo2;   
        }
        int iMaximun()
        {
            if(iNo1 > iNo2)
            {
                return iNo1;
            }
            else
            {
                return iNo2;
            }
        }
};


int main()
{
    int iRet = 0;
    Number nobj;

    nobj.Accept();

    iRet = nobj.iMaximun();

    cout << "Maximun number is : " << iRet;

    return 0;
}