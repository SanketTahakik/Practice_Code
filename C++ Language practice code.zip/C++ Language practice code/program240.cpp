/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Problem on bitwise operator
// Auther        : Tahakik Sanket Rajendra
// Date          : 05/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the number and bit number check bit are on of close
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef unsigned int UINT;

bool CheckBit(UINT iNo , UINT iPos)
{
    UINT iMask = 0X00000001;
    UINT iResult = 0;

    if(iPos < 1 || iPos > 32)
    {
        cout << "Invalid Position\n";
        return false;
    }

    iMask = iMask << (iPos - 1);

    iResult = iNo & iMask;
    if(iResult == iMask)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main()
{
    UINT iValue = 0;
    int iBit = 0;
    bool bRet = false;

    cout << "Enter the nuber :  ";
    cin >> iValue;

    cout << "Enter the bit position (Range shout be 1 to 32) \n";
    cin >> iBit;

    bRet = CheckBit(iValue, iBit);

    if(bRet == true)
    {
        cout << "bit are ON\n";
    }
    else
    {
        cout << "bit are OFF\n";
    }

    return 0;
}


/*
    No :        13

    Binary  :   0   0   0   0   1   1   0   1

    Mask    :   0   0   0   0   0   1   0   0           &      

------------------------------------------------------
  iResult       0   0   0   0   0   1   0   0   




0000    0000    0000    0000    0000    0000    0000    0000

0000    0000    0001    0000    0010    0000    0100    0000

0       0       1       0       2       0       4       0

0X00102040
*/