/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Problem on bitwise operator
// Auther        : Tahakik Sanket Rajendra
// Date          : 06/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the number and 7 bit are close
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef unsigned int UINT;

UINT ToggleBit(UINT iNo )
{
    UINT iMask = 0X40;
    
    return (iNo ^ iMask);
}

int main()
{
    UINT iValue = 0;

    UINT iRet = 0;

    cout << "Enter the nuber :  ";
    cin >> iValue;

    iRet = ToggleBit(iValue);

    cout << "Result is : " << iRet <<  "\n";

    return 0;
}


/*

    iPos = 7

    iNo        0   0   1   1   0   1   0   0 
               0   1   0   0   0   0   0   0        ^
-----------------------------------------------------
               0   0   1   1   0   1   0   0
*/


