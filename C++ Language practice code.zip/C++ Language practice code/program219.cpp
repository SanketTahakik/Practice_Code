/////////////////////////////////////////////////////////////
//
// Function name : CheckPallidrome
// input         : integer
// Output        : integer
// Discption     : Use of OOP problems on Digits
// Auther        : Tahakik Sanket Rajendra
// Date          : 27/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept n number form user and Summation this number
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

class Digits
{
    public:
        int iNo;

        Digits(int X)
        {
            iNo = X;
        }

        int SumDigits()
        {
            int iDigits= 0;
            int iSum = 0;

            while (iNo != 0)
            {
                iDigits = iNo % 10;
                iSum = iSum + iDigits;
                iNo= iNo / 10;
            }
            return iSum;
        }
};

int main()
{
    int iValue = 0;
    int iRet = 0;

    cout << "Enter the number :" << "\n";
    cin >> iValue;

    Digits dobj(iValue);

    iRet = dobj.SumDigits();

    cout << "Summation of digits is : " << iRet << "\n";

//////////////////////////////////////////////////////////////////

    iRet = dobj.SumDigits();

    cout << "Summation of digits is : " << iRet << "\n";
 
    return 0;
}