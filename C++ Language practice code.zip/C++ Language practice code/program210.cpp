/////////////////////////////////////////////////////////////
//
// Function name : CheckPallidrome
// input         : integer
// Output        : integer
// Discption     : Use of OOP pattar printing
// Auther        : Tahakik Sanket Rajendra
// Date          : 27/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : 
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

/*
    input iRow = 4, iCol = 4
    output 

    * * * *
    * * * *
    * * * *
    * * * *
    
*/

void Display(int iRow, int iCol)
{
    int i = 0;
    int j = 0;

    for (i = 0; i < iRow ; i++)
    {
        for(j= 1; j <= iCol; j++)
        {
            cout << "*\t";
        }
        cout << "\n";
    }
    
}

int main()
{
    int iValue1 = 0, iValue2 = 0;
    
    cout << "Enter the row : "<< "\n";
    cin >> iValue1;
    
    cout << "Enter the Col : "<< "\n";
    cin >> iValue2;

    Display(iValue1, iValue2);

    return 0;
}