/////////////////////////////////////////////////////////////
//
// Function name : CheckPallidrome
// input         : integer
// Output        : integer
// Discption     : Use of OOP pattar printing
// Auther        : Tahakik Sanket Rajendra
// Date          : 27/05/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept n number form user and 
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

/*
    input iRow = 4, iCol = 4
    output 

    * * * *
    * * * *
    * * * *
    * * * *
    
*/

class Array
{
    public:
        int iSize;
        int *Arr;

        Array(int iNo)
        {
            iSize = iNo;
            Arr = new int[iSize];
        }

        void Accept()
        {
            cout << "Enter the elements :";
            int iCnt = 0;
            for(iCnt = 0; iCnt < iSize; iCnt++)
            {
                cin >> Arr[iCnt];
            }
        }

        void Display()
        {
            cout << "Elements of array are :" << "\n";
            int iCnt = 0;
            for(iCnt = 0; iCnt < iSize; iCnt++)
            {
                cout << Arr[iCnt] << "\n";
            }
        }
};

int main()
{
    int iNo = 0;

    cout << "Enter number of element  : " <<"\n";
    cin >> iNo;

    Array aobj (iNo);
    aobj.Accept();
    aobj.Display();
    return 0;
}