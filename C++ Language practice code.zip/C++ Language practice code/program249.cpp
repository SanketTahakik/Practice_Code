/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Problem on bitwise operator
// Auther        : Tahakik Sanket Rajendra
// Date          : 06/06/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept the number and bit are close
//
/////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

typedef unsigned int UINT;

// 1111 1111 1111 1111 1111 1111 1011 1111
// F    F    F    F    F    F    B    F

UINT OFFBit(UINT iNo , UINT iPos)
{
     UINT iMask = 0XFFFFFFBF;
    UINT iResult = 0;

    iResult = iNo & iMask;
    
    return iResult;
}

int main()
{
    UINT iValue = 0;
    UINT iBit = 0;
    UINT iRet = 0;

    cout << "Enter the number :  ";
    cin >> iValue;

    cout << "Enter the Position :  ";
    cin >> iBit;

    iRet = OFFBit(iValue, iBit);

    cout << "Result is : " << iRet <<  "\n";

    return 0;
}


/*

    iPos = 7

    iNo        0   0   1   1   0   1   0   0 
               0   1   0   0   0   0   0   0        ^
-----------------------------------------------------
               0   0   1   1   0   1   0   0
*/



/*

    iPos = 7
    iNo = 56

    iNo        0   0   1   1   1   0   0   0 
    iMask      1   0   1   1   1   1   1   1         &
-----------------------------------------------------
   iResult     0   0   1   1   1   0   0   0 

    iPos = 7
    iNo = 120

    iNo        0   1   1   1   1   0   0   0 
    iMask      1   0   1   1   1   1   1   1         &
-----------------------------------------------------
   iResult     0   0   1   1   1   0   0   0
*/


