/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept number from user and count number of digits
//
/////////////////////////////////////////////////////////////

import java.util.*;

class Digits
{
    public int SumDigits(int iValue)
    {
        int iSum = 0;
        int iDigits = 0;

        while(iValue != 0)
        {
            iDigits = iValue % 10;
            iSum = iSum + iDigits;
            iValue = iValue / 10;
        }
        return iSum;
    } 
}

public class program338
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo = sobj.nextInt();

        Digits nobj = new Digits();

        int iRet = nobj.SumDigits(iNo);

        System.out.println("Sum of Digits : "+iRet);
    }
}