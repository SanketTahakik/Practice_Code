/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept number from user and Check number is Armstrong number or not
//
/////////////////////////////////////////////////////////////

import java.util.*;

class Digits
{
    public int CountDigits(int iNo)
    {
        int iCount = 0;

        while(iNo != 0)
        {
            iCount++;
            iNo = iNo / 10;
        }
        return iCount;
    }

    int power(int X, int Y)
    {
        int iPower = 1;

        for(int iCnt = 1; iCnt <= Y; iCnt++)
        {
            iPower = iPower * X;
        }
        return iPower;
    }

    public boolean CheckArmstrong(int iNo)
    {
        int iCount = 0;
        iCount = CountDigits(iNo);

        int iTemp = iNo;
        int iSum = 0;
        int iDigit = 0;
        
        while(iNo != 0)
        {
            iDigit = iNo % 10;
            iSum = iSum + power(iDigit, iCount);
            iNo = iNo / 10;
        }

        if(iSum == iTemp)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

        
}

public class program342
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo = sobj.nextInt();

        Digits nobj = new Digits();

        boolean bRet = nobj.CheckArmstrong(iNo);
        
        if(bRet == true)
        {
            System.out.println("Number is Armstrong");
        }
        else
        {
            System.out.println("Number is not Armstrong");
        }
    }
}

/*
    input = 371
    3^3 + 7^3 + 1^3 = 27 + 343 + 1 == 371
 */