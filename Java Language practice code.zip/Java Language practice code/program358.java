/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Arrary in Java 
// Auther        : Tahakik Sanket Rajendra
// Date          : 04/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String form user and print number of character
//
/////////////////////////////////////////////////////////////

// Approach 2

import java.util.*;

class StringX
{
    public int strLower(String str)
    {
        // step 1 : Convert string to arrary
        char Arr[] = str.toCharArray();

        // step 2 : 
        for(int iCnt = 0; iCnt < Arr.length; iCnt++)
        {
            if(Arr[iCnt] >= 'A' && Arr[iCnt] <= 'Z')
            {
                Arr[iCnt] = (char)(Arr[iCnt] + 32);
            }
        }
        String ret = new String(Arr);

        return ret;
    }

    public int strUpper(String str)
    {
        // step 1 : Convert string to arrary
        char Arr[] = str.toCharArray();
    
        // step 2 : Perform opertion on Arrary
        for(int iCnt = 0; iCnt < Arr.length; iCnt++)
        {
            if(Arr[iCnt] >= 'a' && Arr[iCnt] <= 'z')
            {
                Arr[iCnt] = (char)(Arr[iCnt] - 32);
            }
        }
        // step 3 : convert array to string
        String ret = new String(Arr);
    
        return ret;
    }

    public int strToggle(String str)
    {
        // step 1 : Convert string to arrary
        char Arr[] = str.toCharArray();
    
        // step 2 : Perform opertion on Arrary
        for(int iCnt = 0; iCnt < Arr.length; iCnt++)
        {
            if(Arr[iCnt] >= 'a' && Arr[iCnt] <= 'z')
            {
                Arr[iCnt] = (char)(Arr[iCnt] - 32);
            }
            else if(Arr[iCnt] >= 'A' && Arr[iCnt] <= 'Z')
            {
                Arr[iCnt] = (char)(Arr[iCnt] + 32);
            }
        }
        // step 3 : convert array to string
        String ret = new String(Arr);
    
        return ret;
    }
}


class program358
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);

        System.out.println("Enter your name : ");
        String name = sobj.nextLine();

        StringX obj = new StringX();  
        
        String sret = obj.strLower(name);
        System.out.println("Convert string is : "+sret);

        sret = obj.strUpper(name);
        System.out.println("Convert string in "+ sret);
    }
}