/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Arrary in Java 
// Auther        : Tahakik Sanket Rajendra
// Date          : 04/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String form user and return largest world
//
/////////////////////////////////////////////////////////////

import java.util.*;

class program377
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter the String : ");
        String str = sobj.nextLine();
        
        StringBuffer sbobj = new StringBuffer(str);
        
        sbobj = sbobj.reverse();

        System.out.println(sbobj);
    }
}