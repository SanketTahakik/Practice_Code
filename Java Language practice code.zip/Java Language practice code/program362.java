/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Arrary in Java 
// Auther        : Tahakik Sanket Rajendra
// Date          : 04/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept String form user and remove white space
//
/////////////////////////////////////////////////////////////

// Approach 2

import java.util.*;

class StringX
{
    public String removeWhiteSpace(String str)
    {
        return str.replaceAll("\\s","");
    }   
}

class program362
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);

        System.out.println("Enter your name : ");
        String name = sobj.nextLine();

        StringX obj = new StringX();  
        String sret = obj.removeWhiteSpace(name);

        System.out.println("Result is : "+ sret);
        
    }
}