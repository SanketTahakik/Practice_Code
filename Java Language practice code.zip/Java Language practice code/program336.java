/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept number from user and count number of digits
//
/////////////////////////////////////////////////////////////

import java.util.*;

class Digits
{
    public int CountDigits(int iValue)
    {
        int iCount = 0;
        int iDigits = 0;

        while(iValue != 0)
        {
            iDigits = iValue % 10;
            iCount++;
            iValue = iValue / 10;
        }
        return iCount;
    } 
}

public class program336
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo = sobj.nextInt();

        Digits nobj = new Digits();

        int iRet = nobj.CountDigits(iNo);

        System.out.println("Multiplication of Even factor is : "+iRet);
    }
}