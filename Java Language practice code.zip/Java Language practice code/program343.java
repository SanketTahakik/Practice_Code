/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Arrary in Java 
// Auther        : Tahakik Sanket Rajendra
// Date          : 04/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept number element form user and 
//
/////////////////////////////////////////////////////////////

// Approch

import java.util.*;

public class program343
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter number of element : ");
        int iSize = sobj.nextInt();

        int Arr[] = new int[iSize];

        System.out.println("Enter the element : ");
        int iCnt = 0;

        for(iCnt = 0; iCnt < iSize ; iCnt++)
        {
            Arr[iCnt] = sobj.nextInt();
        }
        
        System.out.println("Element of arrary is :");

        for(iCnt = 0; iCnt < iSize ; iCnt++)
        {
            System.out.println(Arr[iCnt]);
        }
    }
}