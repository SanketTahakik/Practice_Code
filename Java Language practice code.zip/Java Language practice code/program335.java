/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept number and return Even factor
//
/////////////////////////////////////////////////////////////

import java.util.*;

class Numbers 
{
    public int digits(int iValue)
    {
        int iMult = 1;

        for(int iCnt = 2; iCnt <= iValue; iCnt += 2)   // 
        {
            if((iValue % iCnt) == 0)
            {
                iMult = iMult * iCnt;
            }
        }
        
        if(iMult == 1)
        {
            return 0;
        }

        return iMult;
    } 
}

public class program335
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo = sobj.nextInt();

        Numbers nobj = new Numbers();

        int iRet = nobj.digits(iNo);

        System.out.println("Multiplication of Even factor is : "+iRet);
    }
}