/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Java 
//
/////////////////////////////////////////////////////////////


// Approch 2


import java.util.*;

public class program329
{
    public static int Factorial(int iValue)
    {
        int iMult = 1;

        for(int iCnt = 1; iCnt <= iValue; iCnt++)
        {
            iMult = iMult * iCnt;
        }
        return iMult;
    }
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo = sobj.nextInt();

        int iRet = Factorial(iNo);

        System.out.println("Factorial is : "+iRet);
    }
}