/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Java 
//
/////////////////////////////////////////////////////////////

import java.util.*;

public class program326
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo1 = sc.nextInt();
        
        System.out.println("Enter the Second number : ");
        int iNo2 = sc.nextInt();

        int iAns = 0;

        iAns = iNo1 + iNo2;

        System.out.println("Addition is : " +iAns);
    }
}