/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept number from user and Check number is Armstrong number or not
//
/////////////////////////////////////////////////////////////

import java.util.*;

class Digits
{
    public boolean CheckArmstrong(int iNo)
    {
        int iTemp = iNo;
        int iCount = 0;

        while(iTemp != 0)
        {
            iCount++;
            iTemp = iTemp / 10;
        }
        iTemp = iNo;

        int iSum = 0, iPower = 1, iCnt = 0 , iDigit = 0;

        while(iNo != 0)
        {
            iDigit = iNo % 10;

            // Logic to calculet power
            for(iCnt = 1; iCnt <= iCount; iCnt++)
            {
                iPower = iPower * iDigit;
            }

            iSum = iSum + iPower;
            iPower = 1;
            iNo = iNo / 10 ;
        }

        if(iSum == iTemp)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
        
}

public class program341
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo = sobj.nextInt();

        Digits nobj = new Digits();

        boolean bRet = nobj.CheckArmstrong(iNo);
        
        if(bRet == true)
        {
            System.out.println("Number is Armstrong");
        }
        else
        {
            System.out.println("Number is not Armstrong");
        }
    }
}

/*
    input = 371
    3^3 + 7^3 + 1^3 = 27 + 343 + 1 == 371
 */