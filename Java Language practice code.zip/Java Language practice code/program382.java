/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Arrary in Java 
// Auther        : Tahakik Sanket Rajendra
// Date          : 04/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Anagram
//
/////////////////////////////////////////////////////////////

/*
    str1 : Marvellous
    str2 : osulMalver
*/

import java.util.*;

class program382
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter frist String : ");

        String str1 = sobj.nextLine();
        System.out.println("Enter frist String : ");

        String str2 = sobj.nextLine();
        System.out.println("Enter scend String : ");

        str1= str1.toLowerCase();
        str2= str2.toLowerCase();

        char Arr[] = str1.toCharArray();
        char Brr[] = str2.toCharArray();

        int freq1[] = new int[26];
        int freq2[] = new int[26];
        int iCnt = 0;

        for(iCnt = 0; iCnt < Arr.length; iCnt++)
        {
            freq1[Arr[iCnt] - 'a']++;
        }
        for(iCnt = 0; iCnt < Arr.length; iCnt++)
        {
            freq2[Brr[iCnt] - 'a']++;
        }

        for(iCnt = 0; iCnt < freq1.length; iCnt++)
        {
            if(freq1[iCnt] != freq2[iCnt])
            {
                break;
            }
        }
        if(iCnt == freq1.length)
        {
            System.out.println("Strings are anagram");
        }
        else
        {
            System.out.println("String are not anagram");
        }
    }
}