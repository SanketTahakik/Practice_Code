/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept number and return Even factor
//
/////////////////////////////////////////////////////////////


// Approch 3


import java.util.*;

class Numbers 
{
    public int EvenFactorial(int iValue)
    {
        int iMult = 1;

        for(int iCnt = 2; iCnt <= iValue; iCnt += 2)   // 
        {
            if((iValue % iCnt) == 0)
            {
                iMult = iMult * iCnt;
            }
        }
        
        return iMult;
    } 
}

public class program334
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo = sobj.nextInt();

        Numbers nobj = new Numbers();

        int iRet = nobj.EvenFactorial(iNo);

        System.out.println("Multiplication of Even factor is : "+iRet);
    }
}