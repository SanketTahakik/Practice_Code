/////////////////////////////////////////////////////////////
//
// Function name : 
// input         : integer
// Output        : integer
// Discption     : Java
// Auther        : Tahakik Sanket Rajendra
// Date          : 03/07/2023
//
/////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////
//
// Problem Statement : Accept number from user and find Genric Root
//
/////////////////////////////////////////////////////////////

import java.util.*;

class Digits
{
    public int GenericRoot(int iValue)
    {
        int iSum = 0;
        int iDigit = 0;

        while(iValue >= 10)
        {
            while(iValue != 0)
            {
                iDigit = iValue % 10;
                iSum = iSum + iDigit;
                iValue = iValue / 10;
            }
            if(iSum >= 10)
            {
                iValue = iSum;
                iSum = 0;
            }
            else
            {
                iValue = iSum;
                break;
            }
        }
        return iValue;
    } 
}

public class program340
{
    public static void main(String args[])
    {
        Scanner sobj = new Scanner(System.in);
        
        System.out.println("Enter the Frist number : ");
        int iNo = sobj.nextInt();

        Digits nobj = new Digits();

        int iRet = nobj.GenericRoot(iNo);

        System.out.println("Genric Root is : "+iRet);
    }
}

/*
    iNo = 985698

    iSum = 9 + 8 + 7 + 8 + 9 + 8 
    iSum = 49;

    iNo = 49;

    iSum = 4 + 9
    iSum = 13

    iNo = 1 + 3
    
    iSum = 4
 */